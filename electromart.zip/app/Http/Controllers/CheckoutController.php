<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\ProductVariant;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Session;

class CheckoutController extends Controller
{
    public function index()
    {
        $cart = Session::get('cart', []);

        if (empty($cart)) {
            return redirect()->route('cart.index')->with('error', 'Your cart is empty');
        }

        // Calculate Totals
        $subtotal = 0;
        foreach($cart as $item) $subtotal += $item['price'] * $item['quantity'];
        $vat = $subtotal * 0.05;
        $total = $subtotal + $vat;

        return view('frontend.checkout', compact('cart', 'subtotal', 'vat', 'total'));
    }

    public function store(Request $request)
    {
        $request->validate([
            'first_name' => 'required|string',
            'last_name' => 'required|string',
            'email' => 'required|email',
            'phone' => 'required|string',
            'address' => 'required|string',
            'city' => 'required|string',
            'payment_method' => 'required|in:cod,card'
        ]);

        $cart = Session::get('cart', []);
        if (empty($cart)) return redirect()->route('cart.index');

        $subtotal = 0;
        foreach($cart as $item) $subtotal += $item['price'] * $item['quantity'];
        $vat_amount = $subtotal * 0.05;
        $total = $subtotal + $vat_amount;

        $order = DB::transaction(function () use ($request, $cart, $subtotal, $vat_amount, $total) {

            // 1. CRM LOGIC: Find or Create Customer Profile
            // We link orders to a 'Customer' record based on Phone/Email
            // regardless of whether they have a User Account or are a Guest.
            $customer = Customer::where('phone', $request->phone)
                ->orWhere('email', $request->email)
                ->first();

            $fullName = $request->first_name . ' ' . $request->last_name;

            if (!$customer) {
                $customer = Customer::create([
                    'name' => $fullName,
                    'email' => $request->email,
                    'phone' => $request->phone,
                    'address' => $request->address . ', ' . $request->city,
                ]);
            } else {
                // Optional: Update customer address with latest checkout info
                $customer->update([
                    'address' => $request->address . ', ' . $request->city
                ]);
            }

            // 2. CREATE ORDER
            $order = Order::create([
                'invoice_no'       => Order::generateInvoiceNumber(),
                'channel'          => 'online',

                // Link to User if logged in (for account history)
                'user_id'          => auth()->id(),

                // Link to Customer CRM (for support/history)
                'customer_id'      => $customer->id,
                'customer_name'    => $fullName,

                // Guest / Contact Info
                'guest_email'      => $request->email,
                'guest_phone'      => $request->phone,

                // Shipping
                'shipping_address' => $request->address,
                'shipping_city'    => $request->city,
                'shipping_area'    => $request->area,

                // Financials
                'subtotal'         => $subtotal,
                'vat_amount'       => $vat_amount,
                'discount'         => 0,
                'total'            => $total,
                'payment_method'   => $request->payment_method,
                'status'           => 'pending',
            ]);

            // 3. CREATE ORDER ITEMS
            foreach ($cart as $item) {
                OrderItem::create([
                    'order_id'           => $order->id,
                    'product_id'         => $item['product_id'],
                    'product_variant_id' => $item['variant_id'] ?? null,
                    'product_name'       => $item['name'],
                    'quantity'           => $item['quantity'],
                    'unit_price'         => $item['price'],
                    'subtotal'           => $item['price'] * $item['quantity'],
                ]);

                // Deduct Stock
                if (isset($item['variant_id'])) {
                    ProductVariant::where('id', $item['variant_id'])->decrement('stock_quantity', $item['quantity']);
                } else {
                    Product::where('id', $item['product_id'])->decrement('stock_quantity', $item['quantity']);
                }
            }

            Session::forget('cart');

            return $order;
        });

        session()->put('placed_order_id', $order->id);

        return redirect()->route('checkout.success', $order->id);

    }

    public function success($orderId)
    {
        // 1. Find the order
        $order = \App\Models\Order::with('items.product.media')->findOrFail($orderId);
        //$order->load('items.product.media');

        // 2. Security Check (Authorization)
        // We allow access ONLY if:
        // A. The user is logged in AND owns the order
        // B. OR, the user is a guest BUT has the 'placed_order_id' in their session

        $isOwner = auth()->check() && $order->user_id === auth()->id();
        $isGuestOwner = session('placed_order_id') == $order->id;

        if (! $isOwner && ! $isGuestOwner) {
            // If neither, they are trying to peek at someone else's order
            abort(403, 'Unauthorized action.');
        }

        return view('frontend.success', compact('order'));
    }

    public function track(Request $request)
    {
        $request->validate([
            'invoice_no' => 'required',
            'email' => 'required|email',
        ]);

        $order = \App\Models\Order::where('invoice_no', $request->invoice_no)
            ->where('guest_email', $request->email)
            ->first();

        if (!$order) {
            return back()->with('error', 'Order not found.');
        }

        // If found, show the success view again
        return view('frontend.success', compact('order'));
    }
}
