<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Customer;
use Illuminate\Http\Request;
use Carbon\Carbon;

class DashboardController extends Controller
{
    public function index()
    {
        $today = Carbon::today();
        $startOfMonth = Carbon::now()->startOfMonth();

        // 1. Financial Stats
        $dailySales = Order::whereDate('created_at', $today)->sum('total');
        $monthlySales = Order::whereDate('created_at', '>=', $startOfMonth)->sum('total');
        $totalOrders = Order::count();
        $totalCustomers = Customer::count();

        // 2. Low Stock Alerts (Simple Products)
        $lowStockSimple = Product::where('type', 'simple')
            ->whereColumn('stock_quantity', '<=', 'alert_quantity')
            ->take(5)
            ->get();

        // 3. Low Stock Alerts (Variable Products)
        $lowStockVariants = ProductVariant::with('product')
            ->whereColumn('stock_quantity', '<=', 'alert_quantity')
            ->take(5)
            ->get();

        

        // 4. Recent Orders
        $recentOrders = Order::with('customer')->latest()->take(5)->get();

        return view('dashboard', compact(
            'dailySales', 
            'monthlySales', 
            'totalOrders', 
            'totalCustomers',
            'lowStockSimple',
            'lowStockVariants',
            'recentOrders'
        ));
    }
}