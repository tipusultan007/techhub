<?php

namespace App\Http\Controllers;

use App\Models\Category;
use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\Customer;
use App\Models\Order;
use App\Models\OrderItem;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Auth;

class PosController extends Controller
{
    // // 1. Load the POS Interface
    // public function index()
    // {
    //     $customers = Customer::all();
    //     // Load initial products (limit 20 for speed)
    //     $products = Product::with(['variants', 'media'])
    //         ->where('stock_quantity', '>', 0)
    //         ->orWhereHas('variants', fn($q) => $q->where('stock_quantity', '>', 0))
    //         ->latest()
    //         ->limit(20)
    //         ->get();

    //     return view('admin.pos.index', compact('customers', 'products'));
    // }

    // // 2. AJAX Product Search (Barcode or Name)
    // public function search(Request $request)
    // {
    //     $term = $request->term;

    //     // Search Simple Products
    //     $simple = Product::where('type', 'simple')
    //         ->where(function ($q) use ($term) {
    //             $q->where('name', 'LIKE', "%$term%")
    //                 ->orWhere('sku', 'LIKE', "%$term%")
    //                 ->orWhere('barcode', 'LIKE', "%$term%");
    //         })->where('stock_quantity', '>', 0)->get();

    //     // Search Variants
    //     // Updated Variable Product Search
    //     $variants = \App\Models\ProductVariant::with('product')
    //         ->where('stock_quantity', '>', 0)
    //         ->where(function ($q) use ($term) {
    //             $q->where('sku', 'LIKE', "%$term%")
    //                 ->orWhere('barcode', 'LIKE', "%$term%")
    //                 ->orWhere('variant_name', 'LIKE', "%$term%") // Searches "Red / 128GB"
    //                 // Search inside the linked Attribute Values (Professional search)
    //                 ->orWhereHas('attributeValues', function ($subQ) use ($term) {
    //                     $subQ->where('value', 'LIKE', "%$term%");
    //                 });
    //         })
    //         ->get();
    //     // Format data for JS
    //     $results = [];
    //     foreach ($simple as $p) {
    //         $results[] = [
    //             'id' => $p->id,
    //             'variant_id' => null,
    //             'name' => $p->name,
    //             'price' => $p->selling_price,
    //             'image' => $p->getFirstMediaUrl('product_image') ?: asset('no-image.png'),
    //             'stock' => $p->stock_quantity,
    //             'sku' => $p->sku
    //         ];
    //     }
    //     foreach ($variants as $v) {
    //         $results[] = [
    //             'id' => $v->product_id,
    //             'variant_id' => $v->id,
    //             'name' => $v->product->name . ' - ' . $v->variant_name, // "iPhone 15 - Red / 128GB"
    //             'price' => $v->selling_price,
    //             'stock' => $v->stock_quantity,
    //             'sku' => $v->sku
    //         ];
    //     }
    //     return response()->json($results);
    // }

      /**
     * Load the POS Interface with Initial Products
     */
    public function index()
    {
        $customers = Customer::select('id', 'name', 'phone')->latest()->get();
        $categories = Category::select('id', 'name')->orderBy('name')->get();

        // Load initial 30 products for instant display
        $initialProducts = $this->getPosProducts('');

        return view('admin.pos.index', compact('customers', 'categories', 'initialProducts'));
    }

    /**
     * AJAX Search (and Default Load)
     */
    public function search(Request $request)
    {
        $products = $this->getPosProducts($request->term);
        return response()->json($products);
    }

    /**
     * Helper: Unified Query Logic for Simple + Variable Products
     */
    private function getPosProducts($term)
    {
        $queryLimit = 30;

        // 1. Search Simple Products
        $simple = Product::where('type', 'simple')
            ->where('stock_quantity', '>', 0) // Only in stock
            ->when($term, function ($q) use ($term) {
                $q->where(function($sub) use ($term) {
                    $sub->where('name', 'LIKE', "%$term%")
                        ->orWhere('sku', 'LIKE', "%$term%")
                        ->orWhere('barcode', 'LIKE', "%$term%");
                });
            })
            ->latest()
            ->take($queryLimit)
            ->get();

        // 2. Search Variants (Variable Products)
        $variants = ProductVariant::with('product')
            ->where('stock_quantity', '>', 0) // Only in stock
            ->when($term, function ($q) use ($term) {
                $q->where(function($sub) use ($term) {
                    $sub->where('variant_name', 'LIKE', "%$term%") // Search "Red / 128GB"
                        ->orWhere('sku', 'LIKE', "%$term%")
                        ->orWhere('barcode', 'LIKE', "%$term%")
                        ->orWhereHas('product', fn($p) => $p->where('name', 'LIKE', "%$term%"));
                });
            })
            ->latest()
            ->take($queryLimit)
            ->get();

        // 3. Merge & Format Data
        $results = [];

        // Format Simple
        foreach($simple as $p) {
            $results[] = [
                'id' => $p->id,
                'variant_id' => null,
                'name' => $p->name,
                'price' => $p->selling_price,
                'image' => $p->getFirstMediaUrl('product_image'),
                'stock' => $p->stock_quantity,
                'sku' => $p->sku,
                'has_serial_number' => $p->has_serial_number,
                'type' => 'simple'
            ];
        }

        // Format Variants
        foreach($variants as $v) {
            $results[] = [
                'id' => $v->product_id,
                'variant_id' => $v->id,
                'name' => $v->product->name . ' - ' . $v->variant_name,
                'price' => $v->selling_price,
                'image' => $v->product->getFirstMediaUrl('product_image'), // Inherit parent image
                'stock' => $v->stock_quantity,
                'sku' => $v->sku,
                'has_serial_number' => $v->product->has_serial_number,
                'type' => 'variable'
            ];
        }

        return $results;
    }

    // 3. Store Sale (Checkout)
    public function store(Request $request)
{
    // 1. Validation
    $request->validate([
        'items' => 'required|array|min:1',
        'amount_paid' => 'required|numeric|min:0', // This is the Final Total (after discount)
        'discount' => 'nullable|numeric|min:0',
        'payment_method' => 'required|string',
        'customer_id' => 'nullable|exists:customers,id'
    ]);

    try {
        DB::beginTransaction();

        // 2. Calculate Gross Total (Server Side Security)
        $grossTotal = 0;
        foreach ($request->items as $item) {
            $grossTotal += ($item['price'] * $item['qty']);
        }

        // 3. Apply Discount
        $discount = $request->discount ?? 0;
        
        // Final amount the customer actually pays
        $finalPayable = $grossTotal - $discount;

        // Security Check: Optional - Ensure frontend total matches backend total (within small margin)
        // if (abs($finalPayable - $request->amount_paid) > 0.1) {
        //    throw new \Exception("Price mismatch error. Please refresh.");
        // }

        // 4. UAE VAT Logic (Inclusive 5% on Final Payable)
        // Formula: Tax = Total - (Total / 1.05)
        $taxRate = 0.05;
        $netAmount = $finalPayable / (1 + $taxRate); // Excl. VAT
        $vatAmount = $finalPayable - $netAmount;      // The VAT component

        // 5. Generate Invoice Number
        $lastOrder = Order::latest()->first();
        $nextId = $lastOrder ? $lastOrder->id + 1 : 1;
        $invoiceNo = 'INV-' . date('Y') . '-' . str_pad($nextId, 5, '0', STR_PAD_LEFT);

        // 6. Create Order Record
        $order = Order::create([
            'invoice_no' => $invoiceNo,
            'customer_id' => $request->customer_id,
            'customer_name' => $request->customer_id ? Customer::find($request->customer_id)->name : 'Walk-in Customer',
            
            // Financials
            'subtotal' => $netAmount,   // Amount before Tax
            'vat_amount' => $vatAmount, // Tax Amount
            'discount' => $discount,    // Discount applied
            'total' => $finalPayable,   // Final Amount Paid
            
            'payment_method' => $request->payment_method,
            'status' => 'completed',
            'user_id' => Auth::id()
        ]);

        // 7. Process Items
        foreach ($request->items as $item) {
            
            // --- A. Stock Deduction ---
            if (!empty($item['variant_id'])) {
                // Variable Product
                $variant = ProductVariant::lockForUpdate()->find($item['variant_id']);
                if (!$variant || $variant->stock_quantity < $item['qty']) {
                    throw new \Exception("Insufficient stock for variant: " . ($variant->sku ?? 'Unknown'));
                }
                $variant->decrement('stock_quantity', $item['qty']);
                $productNameSnapshot = $variant->product->name . ' - ' . $variant->variant_name;
            } else {
                // Simple Product
                $product = Product::lockForUpdate()->find($item['id']);
                if (!$product || $product->stock_quantity < $item['qty']) {
                    throw new \Exception("Insufficient stock for product: " . ($product->name ?? 'Unknown'));
                }
                $product->decrement('stock_quantity', $item['qty']);
                $productNameSnapshot = $product->name;
            }

            // --- B. Serial Number & Warranty Logic ---
            $serialNumbers = null;
            $warrantyEnd = null;

            if (!empty($item['serial'])) {
                $serialNumbers = $item['serial'];

                // Mark Serial as SOLD
                $serialRecord = \App\Models\ProductSerial::where('serial_number', $item['serial'])
                    ->where('status', 'available')
                    ->first();

                if ($serialRecord) {
                    $serialRecord->update([
                        'status' => 'sold',
                        'order_id' => $order->id
                    ]);
                } else {
                    // Fail safe if serial scanned but sold in another transaction milliseconds ago
                    throw new \Exception("Serial number {$item['serial']} is no longer available.");
                }

                // Calculate Warranty Date
                $product = Product::find($item['id']);
                if ($product->warranty_duration && $product->warranty_type) {
                    $date = now();
                    if ($product->warranty_type == 'months') $date->addMonths($product->warranty_duration);
                    elseif ($product->warranty_type == 'days') $date->addDays($product->warranty_duration);
                    elseif ($product->warranty_type == 'years') $date->addYears($product->warranty_duration);

                    $warrantyEnd = $date;
                }
            }

            // --- C. Create Order Item ---
            OrderItem::create([
                'order_id' => $order->id,
                'product_id' => $item['id'],
                'product_variant_id' => $item['variant_id'] ?? null,
                'product_name' => $productNameSnapshot, // Save snapshot of name
                'quantity' => $item['qty'],
                'unit_price' => $item['price'],
                'subtotal' => $item['price'] * $item['qty'],
                'serial_numbers' => $serialNumbers,
                'warranty_end_date' => $warrantyEnd
            ]);
        }

        DB::commit();
        
        return response()->json([
            'status' => 'success', 
            'order_id' => $order->id,
            'message' => 'Sale processed successfully'
        ]);

    } catch (\Exception $e) {
        DB::rollBack();
        return response()->json([
            'status' => 'error', 
            'message' => $e->getMessage()
        ], 500);
    }
}
    public function checkSerial(Request $request)
    {
        $exists = \App\Models\ProductSerial::where('serial_number', $request->serial)
            ->where('product_id', $request->product_id)
            ->where('status', 'available') // Only unsold items
            ->first();

        if ($exists) {
            return response()->json(['valid' => true]);
        } else {
            return response()->json(['valid' => false, 'message' => 'Serial Invalid or Sold']);
        }
    }
}
