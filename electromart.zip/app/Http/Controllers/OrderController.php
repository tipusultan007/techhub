<?php

namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    /**
     * Display a listing of sales orders.
     */
    public function index()
    {
        $orders = Order::with(['customer', 'user'])
                       ->latest()
                       ->paginate(15);

        return view('admin.orders.index', compact('orders'));
    }

    /**
     * Display the specified order (Invoice View).
     */
    public function show(Order $order)
    {
        // Eager load data needed for details
        $order->load(['items.product', 'customer', 'history.user']);

        // SEPARATION LOGIC:
        if ($order->channel === 'online') {
            // Return the specialized Online Order view (Sidebar, Shipping info, etc.)
            return view('admin.orders.show_online', compact('order'));
        }

        // Return your existing/standard view for POS or generic orders
        return view('admin.orders.show', compact('order'));
    }

    /**
     * Print layout (Thermal Printer 80mm).
     * This method renders the specific print view designed for POS printers.
     */
    public function print(Order $order)
    {
        $order->load(['items']);
        return view('admin.orders.print', compact('order'));
    }

    // App\Http\Controllers\OrderController.php

    public function details(Order $order)
    {
        // Eager load relationships for performance
        $order->load(['items.product', 'customer', 'history.user']);

        return view('admin.orders.details', compact('order'));
    }

    public function updateStatus(Request $request, Order $order)
    {
        $request->validate([
            'status' => 'required|in:pending,processing,shipped,completed,cancelled,returned',
            'comment' => 'nullable|string'
        ]);

        // Update Order Status
        $order->update([
            'status' => $request->status,
        ]);

        // Log Activity
        $order->history()->create([
            'status' => $request->status,
            'comment' => $request->comment ?? 'Status updated to ' . ucfirst($request->status),
            'user_id' => auth()->id(),
        ]);

        return back()->with('success', 'Order status updated successfully.');
    }

    public function destroy(Order $order)
    {
        // Prevent accidental deletion of completed orders (Optional safety check)
         if ($order->status === 'completed') {
             return back()->with('error', 'Cannot delete a completed order. Please mark as returned instead.');
         }

        try {
            DB::transaction(function () use ($order) {

                // 1. Restock Inventory
                foreach ($order->items as $item) {
                    // Check if it's a Variant or Simple Product
                    if ($item->product_variant_id) {
                        $variant = ProductVariant::find($item->product_variant_id);
                        if ($variant) {
                            $variant->increment('stock_quantity', $item->quantity);
                        }
                    } else {
                        $product = Product::find($item->product_id);
                        if ($product) {
                            $product->increment('stock_quantity', $item->quantity);
                        }
                    }
                }

                // 2. Delete Related Data (History/Logs)
                // Note: Order Items are usually deleted automatically via database
                // cascading if you used ->cascadeOnDelete() in migrations.
                // But we delete explicitly here to be safe and trigger model events if any.
                $order->items()->delete();

                if (method_exists($order, 'history')) {
                    $order->history()->delete();
                }

                // 3. Delete the Order Header
                $order->delete();
            });

            return back()->with('success', 'Order deleted and items restocked successfully.');

        } catch (\Exception $e) {
            // Log the error for debugging
            \Log::error("Error deleting order #{$order->id}: " . $e->getMessage());

            return back()->with('error', 'Something went wrong while deleting the order.');
        }
    }
}
