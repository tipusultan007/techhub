<?php $__env->startSection('header', 'Edit Attribute'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto bg-white rounded-lg shadow p-6">
    <form action="<?php echo e(route('attributes.update', $attribute)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        
        <!-- Attribute Name -->
        <div class="mb-6">
            <label class="block text-sm font-bold text-gray-700 mb-2">Attribute Name</label>
            <input type="text" name="name" value="<?php echo e(old('name', $attribute->name)); ?>" 
                   class="w-full border border-gray-300 rounded p-2 focus:ring-blue-500" required>
        </div>

        <!-- Existing Values -->
        <div class="mb-6">
            <label class="block text-sm font-bold text-gray-700 mb-2">Existing Values</label>
            <div class="space-y-3 bg-gray-50 p-4 rounded border">
                <?php $__currentLoopData = $attribute->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="flex gap-2 items-center">
                    <!-- Update existing value -->
                    <input type="text" name="existing_values[<?php echo e($val->id); ?>]" value="<?php echo e($val->value); ?>" 
                           class="w-full border border-gray-300 rounded p-2 bg-white">
                    
                    <!-- Delete Button (Form inside Form workaround not needed, use Link or separate API) -->
                    <!-- We use a button that triggers a hidden form submission or direct link -->
                    <a href="#" onclick="event.preventDefault(); document.getElementById('delete-val-<?php echo e($val->id); ?>').submit();" 
                       class="text-red-500 hover:text-red-700 px-2" title="Delete Value">
                        <i class="fas fa-trash"></i>
                    </a>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <!-- New Values -->
        <div class="mb-6">
            <label class="block text-sm font-bold text-gray-700 mb-2">Add New Values</label>
            <div id="new-values-container" class="space-y-3">
                <!-- JS appends here -->
            </div>
            <button type="button" id="add-value-btn" class="mt-2 text-sm text-blue-600 font-bold hover:underline">
                + Add New Value Row
            </button>
        </div>

        <div class="flex justify-end pt-4 border-t gap-3">
            <a href="<?php echo e(route('attributes.index')); ?>" class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">Cancel</a>
            <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded font-bold hover:bg-blue-700">Update Attribute</button>
        </div>
    </form>

    <!-- Hidden Delete Forms for Values -->
    <?php $__currentLoopData = $attribute->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form id="delete-val-<?php echo e($val->id); ?>" action="<?php echo e(route('attributes.value.destroy', $val->id)); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<script>
    $(document).ready(function() {
        $('#add-value-btn').click(function() {
            let html = `
            <div class="flex gap-2">
                <input type="text" name="new_values[]" class="w-full border border-gray-300 rounded p-2" placeholder="New Value" required>
                <button type="button" class="text-red-500 hover:text-red-700 px-2 remove-row">
                    <i class="fas fa-trash"></i>
                </button>
            </div>`;
            $('#new-values-container').append(html);
        });

        $(document).on('click', '.remove-row', function() {
            $(this).parent().remove();
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/admin/attributes/edit.blade.php ENDPATH**/ ?>