<?php $__env->startSection('header', 'Stock Valuation Report'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">

    <!-- Summary -->
    <div class="bg-white p-6 rounded-lg shadow mb-6 flex justify-between items-center">
        <div>
            <h3 class="text-lg font-bold text-gray-700">Total Asset Value (Cost Price)</h3>
            <p class="text-sm text-gray-500">Based on current stock and unit cost.</p>
        </div>
        <div class="text-right">
            <p class="text-3xl font-bold text-green-600">AED <?php echo e(number_format($grandTotalValue, 2)); ?></p>
            <p class="text-sm font-bold text-gray-600"><?php echo e($totalItems); ?> Total Units</p>
        </div>
    </div>

    <!-- Simple Products Table -->
    <div class="mb-8">
        <h3 class="font-bold text-gray-800 mb-2 text-lg">Simple Products Inventory</h3>
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <table class="min-w-full divide-y divide-gray-200 text-sm">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left font-bold text-gray-500 uppercase">Product</th>
                        <th class="px-6 py-3 text-left font-bold text-gray-500 uppercase">SKU</th>
                        <th class="px-6 py-3 text-right font-bold text-gray-500 uppercase">Stock</th>
                        <th class="px-6 py-3 text-right font-bold text-gray-500 uppercase">Unit Cost</th>
                        <th class="px-6 py-3 text-right font-bold text-gray-500 uppercase">Total Value</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200 bg-white">
                    <?php $__currentLoopData = $simpleProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-3 font-bold text-gray-800"><?php echo e($p->name); ?></td>
                        <td class="px-6 py-3 font-mono text-gray-500"><?php echo e($p->sku); ?></td>
                        <td class="px-6 py-3 text-right <?php echo e($p->stock_quantity <= 5 ? 'text-red-600 font-bold' : ''); ?>"><?php echo e($p->stock_quantity); ?></td>
                        <td class="px-6 py-3 text-right"><?php echo e(number_format($p->cost_price, 2)); ?></td>
                        <td class="px-6 py-3 text-right font-bold text-gray-800"><?php echo e(number_format($p->stock_quantity * $p->cost_price, 2)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Variable Products Table -->
    <div>
        <h3 class="font-bold text-gray-800 mb-2 text-lg">Variable Products Inventory</h3>
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <table class="min-w-full divide-y divide-gray-200 text-sm">
                <thead class="bg-gray-100">
                    <tr>
                        <th class="px-6 py-3 text-left font-bold text-gray-500 uppercase">Product Name</th>
                        <th class="px-6 py-3 text-left font-bold text-gray-500 uppercase">Variant</th>
                        <th class="px-6 py-3 text-left font-bold text-gray-500 uppercase">SKU</th>
                        <th class="px-6 py-3 text-right font-bold text-gray-500 uppercase">Stock</th>
                        <th class="px-6 py-3 text-right font-bold text-gray-500 uppercase">Unit Cost</th>
                        <th class="px-6 py-3 text-right font-bold text-gray-500 uppercase">Total Value</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200 bg-white">
                    <?php $__currentLoopData = $variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="px-6 py-3 font-bold text-gray-800"><?php echo e($v->product->name); ?></td>
                        <td class="px-6 py-3 text-blue-600"><?php echo e($v->variant_name); ?></td>
                        <td class="px-6 py-3 font-mono text-gray-500"><?php echo e($v->sku); ?></td>
                        <td class="px-6 py-3 text-right <?php echo e($v->stock_quantity <= 5 ? 'text-red-600 font-bold' : ''); ?>"><?php echo e($v->stock_quantity); ?></td>
                        <td class="px-6 py-3 text-right"><?php echo e(number_format($v->cost_price, 2)); ?></td>
                        <td class="px-6 py-3 text-right font-bold text-gray-800"><?php echo e(number_format($v->stock_quantity * $v->cost_price, 2)); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/admin/reports/inventory.blade.php ENDPATH**/ ?>