<?php $__env->startSection('title', 'My Account | Tech Hub'); ?>



<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="page-header">
            <h1 class="page-title">My Dashboard</h1>
            <span style="font-size: 0.9rem; color: var(--text-muted);">
            Member since <?php echo e(Auth::guard('customer')->user()->created_at->format('M Y')); ?>

        </span>
        </div>

        <div class="account-layout">

            <!-- INCLUDE SIDEBAR PARTIAL -->
            <?php echo $__env->make('frontend.customer.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

            <!-- DASHBOARD CONTENT -->
            <div class="dash-content">

                <!-- Stats Grid -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon bg-blue-light"><i class="ri-box-3-fill"></i></div>
                        <div class="stat-info">
                            <h4>Total Orders</h4>
                            <span><?php echo e($totalOrders); ?></span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon bg-orange-light"><i class="ri-time-fill"></i></div>
                        <div class="stat-info">
                            <h4>Pending</h4>
                            <span><?php echo e($pendingOrders); ?></span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon bg-green-light"><i class="ri-wallet-3-fill"></i></div>
                        <div class="stat-info">
                            <h4>Wallet</h4>
                            <span><?php echo e(number_format($walletBalance, 2)); ?></span>
                        </div>
                    </div>
                </div>

                <!-- Recent Orders Table -->
                <div class="content-card">
                    <div class="card-header">
                        <h2 class="card-title">Recent Orders</h2>
                        <a href="<?php echo e(route('customer.orders')); ?>" class="link-btn">View All</a>
                    </div>
                    <div class="table-responsive">
                        <table class="order-table">
                            <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Date</th>
                                <th>Status</th>
                                <th>Total</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td style="font-weight:600;">#<?php echo e($order->invoice_no); ?></td>
                                    <td><?php echo e($order->created_at->format('M d, Y')); ?></td>
                                    <td><span class="status-badge status-<?php echo e($order->status); ?>"><?php echo e(ucfirst($order->status)); ?></span></td>
                                    <td><?php echo e(number_format($order->total, 2)); ?> AED</td>
                                    <td><a href="<?php echo e(route('customer.orders.show', $order)); ?>" class="btn-sm-outline">View</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="5" class="text-center p-4">No recent orders.</td></tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/frontend/customer/dashboard.blade.php ENDPATH**/ ?>