<?php $__env->startSection('title', 'Home | Tech Hub Computer Trading'); ?>
<?php $__env->startSection('meta_description', 'Best deals on Gaming PCs, Laptops, and Components in UAE.'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="hero">
            <div class="hero-banner">
                <img src="https://images.unsplash.com/photo-1603481588233-f6e1f05a84e6?q=80&w=1200&auto=format&fit=crop" alt="Gaming Setup">
                <div class="banner-content">
                    <span style="background:var(--brand-magenta); padding:4px 10px; font-size:11px; border-radius:20px; font-weight:700;">NEW ARRIVALS</span>
                    <h2>Ultimate <br>Performance</h2>
                    <p style="margin-bottom:25px; font-size:15px; opacity:0.9;">Custom loops, RTX 4090s, and high-airflow cases. Build your dream rig today.</p>
                    <button class="btn btn-brand">Shop Custom Builds</button>
                </div>
            </div>
            <div class="hero-side">
                <div class="promo-box">
                    <div class="promo-text">
                        <h4>Graphics Cards</h4>
                        <p>RTX 40-Series Stock</p>
                    </div>
                    <img src="https://images.unsplash.com/photo-1591488320449-011701bb6704?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" width="70" alt="GPU">
                </div>
                <div class="promo-box">
                    <div class="promo-text">
                        <h4>Gaming Gear</h4>
                        <p>Mechanical Keyboards</p>
                    </div>
                    <img src="https://images.unsplash.com/photo-1595225476474-87563907a212?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" width="70" alt="Keyboard">
                </div>
            </div>
        </div>

        <!-- NEW: SERVICE FEATURES ROW -->
        <div class="section-wrapper">
            <div class="services-row">
                <div class="service-box">
                    <div class="s-icon"><i class="ri-macbook-line"></i></div>
                    <div class="s-info">
                        <h4>Laptop Finder</h4>
                        <p>Find Your Laptop Easily</p>
                    </div>
                </div>
                <div class="service-box">
                    <div class="s-icon"><i class="ri-chat-voice-line"></i></div>
                    <div class="s-info">
                        <h4>Raise a Complain</h4>
                        <p>Share your experience</p>
                    </div>
                </div>
                <div class="service-box">
                    <div class="s-icon"><i class="ri-home-gear-line"></i></div>
                    <div class="s-info">
                        <h4>Home Service</h4>
                        <p>Get expert help.</p>
                    </div>
                </div>
                <div class="service-box">
                    <div class="s-icon"><i class="ri-settings-3-line"></i></div>
                    <div class="s-info">
                        <h4>Servicing Center</h4>
                        <p>Repair Your Device</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- NEW: FEATURED CATEGORIES GRID -->
        <div class="section-wrapper">
            <div class="section-center-header">
                <h3>Featured Category</h3>
                <p>Get Your Desired Product from Featured Category!</p>
            </div>

            <div class="category-grid">
                <a href="#" class="cat-item">
                    <i class="ri-router-line"></i>
                    <span>Starlink</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-fire-line"></i>
                    <span>Water Heater</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-flight-takeoff-line"></i>
                    <span>Drone</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-camera-lens-line"></i>
                    <span>Gimbal</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-tablet-line"></i>
                    <span>Tablet PC</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-tv-line"></i>
                    <span>TV</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-smartphone-line"></i>
                    <span>Mobile Phone</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-plug-line"></i>
                    <span>Accessories</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-hard-drive-2-line"></i>
                    <span>Portable SSD</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-webcam-line"></i>
                    <span>WiFi Camera</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-scissors-cut-line"></i>
                    <span>Trimmer</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-watch-line"></i>
                    <span>Smart Watch</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-vidicon-line"></i>
                    <span>Action Camera</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-headphone-line"></i>
                    <span>Earbuds</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-speaker-line"></i>
                    <span>Speakers</span>
                </a>
                <a href="#" class="cat-item">
                    <i class="ri-gamepad-line"></i>
                    <span>Console</span>
                </a>
            </div>
        </div>

        <!-- FLASH DEALS -->
        <div class="section-wrapper">
            <div class="section-header">
                <div class="sec-title">
                    <i class="ri-flashlight-fill" style="color: #ef4444;"></i> Flash Sale
                    <div class="deal-header">
                        Ends in:
                        <div class="timer-box">
                            <span class="time-block">02</span> : <span class="time-block">45</span> : <span class="time-block">10</span>
                        </div>
                    </div>
                </div>
                <a href="#" class="view-all">See All Offers <i class="ri-arrow-right-s-line"></i></a>
            </div>

            <div class="grid-5">
                <div class="product-card">
                    <div class="badge-sale">-20%</div>
                    <div class="p-img"><img src="https://images.unsplash.com/photo-1615663245857-ac93bb7c39e7?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Mouse"></div>
                    <div class="p-details">
                        <div class="p-cat">Accessories</div>
                        <div class="p-title">Logitech G Pro X Superlight Wireless Mouse</div>
                        <div class="p-rating"><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-fill"></i><i class="ri-star-half-fill"></i> <span>(420)</span></div>
                        <div class="p-price">450 AED <span class="p-old">599</span></div>
                        <button class="add-cart-hover">Add to Cart</button>
                    </div>
                </div>
                <div class="product-card">
                    <div class="badge-sale">-15%</div>
                    <div class="p-img"><img src="https://images.unsplash.com/photo-1593640408182-31c70c8268f5?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Monitor"></div>
                    <div class="p-details">
                        <div class="p-cat">Monitors</div>
                        <div class="p-title">Dell Alienware 34" Curved QD-OLED Monitor</div>
                        <div class="p-price">3,299 AED <span class="p-old">3,899</span></div>
                        <button class="add-cart-hover">Add to Cart</button>
                    </div>
                </div>
                <div class="product-card">
                    <div class="badge-sale">-10%</div>
                    <div class="p-img"><img src="https://images.unsplash.com/photo-1587831990711-23ca6441447b?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Laptop"></div>
                    <div class="p-details">
                        <div class="p-cat">Laptops</div>
                        <div class="p-title">ASUS ROG Zephyrus G14 Ryzen 9 RTX 4060</div>
                        <div class="p-price">5,499 AED <span class="p-old">6,100</span></div>
                        <button class="add-cart-hover">Add to Cart</button>
                    </div>
                </div>
                <div class="product-card">
                    <div class="badge-sale">-25%</div>
                    <div class="p-img"><img src="https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Tablet"></div>
                    <div class="p-details">
                        <div class="p-cat">Tablets</div>
                        <div class="p-title">Apple iPad Pro 11-inch M4 Chip Space Black</div>
                        <div class="p-price">3,899 AED <span class="p-old">4,200</span></div>
                        <button class="add-cart-hover">Add to Cart</button>
                    </div>
                </div>
                <div class="product-card">
                    <div class="badge-sale">-30%</div>
                    <div class="p-img"><img src="https://images.unsplash.com/photo-1505740420928-5e560c06d30e?ixlib=rb-4.0.3&auto=format&fit=crop&w=300&q=80" alt="Headphone"></div>
                    <div class="p-details">
                        <div class="p-cat">Audio</div>
                        <div class="p-title">Sony WH-1000XM5 Noise Cancelling Silver</div>
                        <div class="p-price">999 AED <span class="p-old">1,400</span></div>
                        <button class="add-cart-hover">Add to Cart</button>
                    </div>
                </div>
            </div>
        </div>

        <div class="mid-banner">
            <div class="mb-text">
                <h3>Upgrade Your Office</h3>
                <p>Exclusive corporate deals on Workstations, Servers, and Networking Gear.</p>
            </div>
            <button class="mb-btn">Request Quote</button>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/frontend/home.blade.php ENDPATH**/ ?>