<?php $__env->startSection('header', 'Process a Return/Refund'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-xl mx-auto bg-white rounded-lg shadow p-6">
    <form action="<?php echo e(route('returns.find')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label class="block text-sm font-bold text-gray-700 mb-2">Enter Invoice Number</label>
        <div class="flex gap-2">
            <input type="text" name="invoice_no" class="w-full border rounded p-2" placeholder="e.g. INV-2025-00123" required>
            <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded font-bold hover:bg-blue-700">Find Order</button>
        </div>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/admin/returns/create.blade.php ENDPATH**/ ?>