<?php $__env->startSection('title', 'Checkout | Tech Hub'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* Checkout Specific Styles */
        .checkout-title { margin: 30px 0; font-size: 1.8rem; font-weight: 800; display: flex; align-items: center; gap: 15px; color: var(--text-main); }
        .checkout-title i { font-size: 1.2rem; color: var(--text-muted); }

        .checkout-layout { display: grid; grid-template-columns: 1.5fr 1fr; gap: 40px; margin-bottom: 60px; }

        /* Forms */
        .checkout-section { background: white; border: 1px solid var(--border); border-radius: var(--radius); padding: 30px; margin-bottom: 25px; box-shadow: var(--shadow); }
        .section-head { font-size: 1.1rem; font-weight: 700; margin-bottom: 20px; color: var(--text-main); display: flex; justify-content: space-between; align-items: center; }

        .edit-link { font-size: 0.85rem; color: var(--brand-magenta); cursor: pointer; text-decoration: underline; }

        .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .form-group { margin-bottom: 15px; }
        .full-width { grid-column: span 2; }

        .form-label { display: block; font-size: 0.85rem; font-weight: 600; margin-bottom: 8px; color: var(--text-main); }
        .form-input { width: 100%; padding: 12px; border: 1px solid var(--border); border-radius: var(--radius); font-size: 0.95rem; outline: none; transition: 0.2s; background: #fff; }
        .form-input:focus { border-color: var(--brand-magenta); box-shadow: 0 0 0 3px rgba(192, 77, 238, 0.1); }

        /* Payment Radio Cards */
        .payment-options { display: flex; flex-direction: column; gap: 15px; }
        .pay-radio { display: none; }
        .pay-card { border: 1px solid var(--border); border-radius: var(--radius); padding: 20px; cursor: pointer; display: flex; align-items: center; gap: 15px; transition: 0.2s; }
        .pay-radio:checked + .pay-card { border-color: var(--brand-deep-blue); background: #f0f9ff; box-shadow: 0 0 0 1px var(--brand-deep-blue); }

        .radio-circle { width: 20px; height: 20px; border: 2px solid #cbd5e1; border-radius: 50%; display: flex; align-items: center; justify-content: center; }
        .pay-radio:checked + .pay-card .radio-circle { border-color: var(--brand-deep-blue); }
        .radio-dot { width: 10px; height: 10px; background: var(--brand-deep-blue); border-radius: 50%; display: none; }
        .pay-radio:checked + .pay-card .radio-dot { display: block; }

        /* Summary */
        .summary-sticky { position: sticky; top: 110px; }
        .order-summary { background: white; border: 1px solid var(--border); border-radius: var(--radius); padding: 25px; box-shadow: var(--shadow); }
        .item-row { display: flex; gap: 15px; margin-bottom: 20px; padding-bottom: 20px; border-bottom: 1px solid #f1f5f9; }
        .item-thumb { width: 60px; height: 60px; background: #f8fafc; border-radius: 6px; display: flex; align-items: center; justify-content: center; padding: 5px; border: 1px solid #f1f5f9; }
        .item-thumb img { max-height: 100%; mix-blend-mode: multiply; }
        .item-name { font-size: 0.9rem; font-weight: 600; line-height: 1.3; color: var(--text-main); }

        .place-order-btn { background: var(--brand-gradient); color: white; width: 100%; border: none; padding: 18px; border-radius: var(--radius); font-weight: 700; font-size: 1.1rem; cursor: pointer; margin-top: 25px; transition: 0.3s; display: flex; justify-content: center; align-items: center; gap: 10px; box-shadow: 0 4px 15px rgba(192, 77, 238, 0.3); }
        .place-order-btn:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(192, 77, 238, 0.4); }

        /* Guest Alert */
        .guest-alert { background: #f0fdf4; border: 1px solid #bbf7d0; color: #166534; padding: 15px; border-radius: var(--radius); margin-bottom: 20px; font-size: 0.9rem; display: flex; gap: 10px; align-items: center; }

        @media (max-width: 900px) { .checkout-layout { grid-template-columns: 1fr; } }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="checkout-title">
            Checkout <i class="ri-arrow-right-s-line"></i> <span style="font-size:1rem; color:var(--text-muted); font-weight:400;">Secure Payment</span>
        </div>

        <form action="<?php echo e(route('checkout.store')); ?>" method="POST" class="checkout-layout">
            <?php echo csrf_field(); ?>

            <!-- LEFT COLUMN: INPUTS -->
            <div class="checkout-forms">

                <!-- 1. Contact Info -->
                <div class="checkout-section">
                    <div class="section-head">
                        1. Contact Information
                        <?php if(auth()->guard()->guest()): ?>
                            <a href="<?php echo e(route('login')); ?>" class="edit-link">Already have an account? Login</a>
                        <?php endif; ?>
                    </div>

                    <?php if(auth()->guard()->check()): ?>
                        <div class="guest-alert">
                            <i class="ri-user-smile-line text-lg"></i>
                            <div>
                                Logged in as <strong><?php echo e(auth()->user()->name); ?></strong> (<?php echo e(auth()->user()->email); ?>)
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="form-group">
                        <label class="form-label">Email Address <span class="text-red-500">*</span></label>
                        <input type="email" name="email" class="form-input"
                               value="<?php echo e(auth()->check() ? auth()->user()->email : old('email')); ?>"
                               placeholder="e.g. name@example.com" required>
                        <p style="font-size: 11px; color: #64748b; margin-top: 5px;">
                            We'll send the receipt and order updates here.
                        </p>
                    </div>
                </div>

                <!-- 2. Shipping Info -->
                <div class="checkout-section">
                    <div class="section-head">2. Shipping Address</div>
                    <div class="form-grid">
                        <div class="form-group">
                            <label class="form-label">First Name <span class="text-red-500">*</span></label>
                            <input type="text" name="first_name" class="form-input"
                                   value="<?php echo e(old('first_name', auth()->user()->name ?? '')); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Last Name <span class="text-red-500">*</span></label>
                            <input type="text" name="last_name" class="form-input" value="<?php echo e(old('last_name')); ?>" required>
                        </div>
                        <div class="form-group full-width">
                            <label class="form-label">Mobile Number (UAE) <span class="text-red-500">*</span></label>
                            <input type="tel" name="phone" class="form-input" placeholder="+971 50 123 4567" value="<?php echo e(old('phone')); ?>" required>
                        </div>
                        <div class="form-group full-width">
                            <label class="form-label">Address <span class="text-red-500">*</span></label>
                            <input type="text" name="address" class="form-input" placeholder="e.g. Street, Building, Flat no." value="<?php echo e(old('address')); ?>" required>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Emirate <span class="text-red-500">*</span></label>
                            <select name="city" class="form-input" required>
                                <option value="">Select Emirate</option>
                                <option value="Dubai" selected>Dubai</option>
                                <option value="Abu Dhabi">Abu Dhabi</option>
                                <option value="Sharjah">Sharjah</option>
                                <option value="Ajman">Ajman</option>
                                <option value="Ras Al Khaimah">Ras Al Khaimah</option>
                                <option value="Fujairah">Fujairah</option>
                                <option value="Umm Al Quwain">Umm Al Quwain</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label class="form-label">Area (Optional)</label>
                            <input type="text" name="area" class="form-input" placeholder="e.g. Dubai Marina" value="<?php echo e(old('area')); ?>">
                        </div>
                    </div>
                </div>

                <!-- 3. Payment Method -->
                <div class="checkout-section">
                    <div class="section-head">3. Payment Method</div>
                    <div class="payment-options">

                        <!-- COD -->
                        <div>
                            <input type="radio" name="payment_method" id="pay-cod" value="cod" class="pay-radio" checked>
                            <label for="pay-cod" class="pay-card">
                                <div class="radio-circle"><div class="radio-dot"></div></div>
                                <div style="flex:1;">
                                    <span style="font-weight:700; color:var(--text-main); display:block;">Cash on Delivery</span>
                                    <span style="font-size:0.85rem; color:#64748b;">Pay with cash upon delivery</span>
                                </div>
                                <i class="ri-hand-coin-line" style="font-size:1.5rem; color:#64748b;"></i>
                            </label>
                        </div>

                        <!-- Card (Placeholder for now) -->
                        <div>
                            <input type="radio" name="payment_method" id="pay-card" value="card" class="pay-radio">
                            <label for="pay-card" class="pay-card">
                                <div class="radio-circle"><div class="radio-dot"></div></div>
                                <div style="flex:1;">
                                    <span style="font-weight:700; color:var(--text-main); display:block;">Credit / Debit Card</span>
                                    <span style="font-size:0.85rem; color:#64748b;">Secure online payment</span>
                                </div>
                                <div style="display:flex; gap:10px; font-size:1.5rem; color:#64748b;">
                                    <i class="ri-visa-line"></i>
                                    <i class="ri-mastercard-line"></i>
                                </div>
                            </label>
                        </div>

                    </div>
                </div>
            </div>

            <!-- RIGHT COLUMN: SUMMARY -->
            <div class="summary-wrapper">
                <div class="summary-sticky">
                    <div class="order-summary">
                        <h3 style="margin-bottom:20px; font-size:1.1rem; font-weight:800; color:var(--text-main);">Order Summary</h3>

                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item-row">
                                <div class="item-thumb">
                                    <img src="<?php echo e($item['image']); ?>" alt="<?php echo e($item['name']); ?>">
                                </div>
                                <div style="flex:1;">
                                    <div class="item-name"><?php echo e($item['name']); ?></div>
                                    <div style="font-size:0.8rem; color:#64748b;">Qty: <?php echo e($item['quantity']); ?></div>
                                </div>
                                <div style="font-weight:700; font-size:0.95rem;">
                                    <?php echo e(number_format($item['price'] * $item['quantity'])); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div style="margin:20px 0; border-bottom:1px solid #f1f5f9;"></div>

                        <div style="display:flex; justify-content:space-between; margin-bottom:12px; font-size:0.95rem; color:#64748b;">
                            <span>Subtotal</span>
                            <span><?php echo e(number_format($subtotal, 2)); ?> AED</span>
                        </div>
                        <div style="display:flex; justify-content:space-between; margin-bottom:12px; font-size:0.95rem; color:#64748b;">
                            <span>Shipping</span>
                            <span class="text-green-600 font-bold">Free</span>
                        </div>
                        <div style="display:flex; justify-content:space-between; margin-bottom:12px; font-size:0.95rem; color:#64748b;">
                            <span>VAT (5%)</span>
                            <span><?php echo e(number_format($vat, 2)); ?> AED</span>
                        </div>

                        <div style="border-top:1px solid #e2e8f0; padding-top:20px; margin-top:20px; font-size:1.3rem; font-weight:800; color:var(--brand-deep-blue); display:flex; justify-content:space-between; align-items:center;">
                            <span>Total</span>
                            <span><?php echo e(number_format($total, 2)); ?> AED</span>
                        </div>

                        <button type="submit" class="place-order-btn">
                            Place Order <i class="ri-arrow-right-line"></i>
                        </button>

                        <div style="text-align:center; font-size:0.8rem; color:#64748b; margin-top:15px; display:flex; justify-content:center; align-items:center; gap:5px;">
                            <i class="ri-lock-2-fill"></i> Guaranteed Safe & Secure Checkout
                        </div>
                    </div>
                </div>
            </div>

        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/frontend/checkout.blade.php ENDPATH**/ ?>