<div>
    <!-- I begin to speak only when I am certain what I will say is not better left unsaid. - Cato the Younger -->
</div>
<?php /**PATH C:\wamp64\www\electromart\resources\views/admin/customers/show.blade.php ENDPATH**/ ?>