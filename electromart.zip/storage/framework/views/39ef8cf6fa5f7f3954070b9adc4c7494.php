

<?php $__env->startSection('header', 'Product Inventory'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">
    <!-- Top Action Bar (Print and Add) -->
    <div class="flex flex-col md:flex-row justify-between items-center mb-6 gap-4">
        
        <!-- Search -->
        <div class="w-full md:w-1/3 relative">
            <input type="text" placeholder="Search products..." class="w-full pl-10 pr-4 py-2 border rounded-lg">
            <i class="fas fa-search absolute left-3 top-2.5 text-gray-400"></i>
        </div>

        <!-- Action Buttons -->
        <div class="flex gap-2">
            <!-- Print Labels Button -->
            <button type="button" onclick="document.getElementById('barcode-form').submit();" class="bg-slate-800 text-white px-4 py-2 rounded shadow hover:bg-slate-700 font-bold text-sm">
                <i class="fas fa-barcode mr-2"></i> Print Labels
            </button>
            
            <!-- Add Product Link -->
            <a href="<?php echo e(route('products.create')); ?>" class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded shadow flex items-center">
                <i class="fas fa-plus mr-2"></i> Add Product
            </a>
        </div>
    </div>

    <!-- Data Table (No longer wrapped in a form) -->
    <div class="bg-white rounded-lg shadow overflow-hidden border border-gray-200">
        <div class="overflow-x-auto">
            <!-- Form for barcode printing is now separate -->
            <form action="<?php echo e(route('products.print_barcodes')); ?>" method="POST" target="_blank" id="barcode-form">
                <?php echo csrf_field(); ?>
                
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 w-12"><input type="checkbox" id="select-all"></th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Product</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Type</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Category / Brand</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Price (AED)</th>
                            <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Stock</th>
                            <th class="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Actions</th>
                        </tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="hover:bg-gray-50 transition">
                                <td class="px-6 py-4">
                                    <input type="checkbox" name="ids[]" value="<?php echo e($product->id); ?>" class="product-checkbox">
                                </td>
                                
                                <!-- Product Name & Image -->
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <div class="flex items-center">
                                        <div class="flex-shrink-0 h-10 w-10">
                                            <?php if($product->hasMedia('product_image')): ?>
                                                <img class="h-10 w-10 rounded object-cover border" src="<?php echo e($product->getFirstMediaUrl('product_image')); ?>">
                                            <?php else: ?>
                                                <div class="h-10 w-10 rounded bg-gray-100 flex items-center justify-center text-gray-400 border"><i class="fas fa-image"></i></div>
                                            <?php endif; ?>
                                        </div>
                                        <div class="ml-4">
                                            <div class="text-sm font-medium text-gray-900"><?php echo e($product->name); ?></div>
                                            <?php if($product->type === 'simple'): ?>
                                                <div class="text-xs text-gray-500">SKU: <?php echo e($product->sku); ?></div>
                                            <?php else: ?>
                                                <div class="text-xs text-gray-500"><?php echo e($product->variants->count()); ?> Variants</div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </td>

                                <!-- Type Badge -->
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php if($product->type === 'simple'): ?>
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">Simple</span>
                                    <?php else: ?>
                                        <span class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">Variable</span>
                                    <?php endif; ?>
                                </td>

                                <!-- Category & Brand -->
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                    <div><?php echo e($product->category->name ?? '-'); ?></div>
                                    <div class="text-xs"><?php echo e($product->brand->name ?? '-'); ?></div>
                                </td>

                                <!-- Price -->
                                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-semibold">
                                    <?php if($product->type === 'simple'): ?>
                                        <?php echo e(number_format($product->selling_price, 2)); ?>

                                    <?php else: ?>
                                        <span class="text-xs text-gray-500">From</span> <?php echo e(number_format($product->variants->min('selling_price'), 2)); ?>

                                    <?php endif; ?>
                                </td>

                                <!-- Stock -->
                                <td class="px-6 py-4 whitespace-nowrap">
                                    <?php
                                        $totalStock = $product->type === 'simple' ? $product->stock_quantity : $product->variants->sum('stock_quantity');
                                    ?>
                                    <?php if($totalStock == 0): ?>
                                        <span class="text-red-600 font-bold text-xs bg-red-100 px-2 py-1 rounded">OUT OF STOCK</span>
                                    <?php elseif($totalStock < 10): ?>
                                        <span class="text-orange-600 font-bold text-sm"><?php echo e($totalStock); ?></span>
                                    <?php else: ?>
                                        <span class="text-green-600 font-bold text-sm"><?php echo e($totalStock); ?></span>
                                    <?php endif; ?>
                                </td>

                                <!-- Actions -->
                                <td class="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                                    <div class="flex justify-end items-center space-x-4">
                                        <a href="<?php echo e(route('products.show', $product)); ?>" class="text-gray-500 hover:text-blue-600" title="View"><i class="fas fa-eye"></i></a>
                                        <a href="<?php echo e(route('products.edit', $product)); ?>" class="text-indigo-600 hover:text-indigo-900" title="Edit"><i class="fas fa-edit"></i></a>
                                        
                                        <!-- FIX: Changed to a button with onclick -->
                                        <button type="button" onclick="confirmDelete(<?php echo e($product->id); ?>)" class="text-red-500 hover:text-red-700" title="Delete">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7" class="px-6 py-10 text-center text-gray-500 bg-gray-50">
                                    No products found.
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </form> <!-- Barcode form now wraps only the table -->
        </div>

        <!-- Pagination -->
        <?php if(method_exists($products, 'links')): ?>
            <div class="px-6 py-4 border-t border-gray-200 bg-white rounded-b-lg shadow">
                <?php echo e($products->links()); ?>

            </div>
        <?php endif; ?>
    </div>

    <!-- FIX: Hidden Delete Forms (One for each product) -->
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form id="delete-form-<?php echo e($product->id); ?>" action="<?php echo e(route('products.destroy', $product)); ?>" method="POST" style="display: none;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        // Checkbox "Select All" logic
        document.getElementById('select-all').onclick = function() {
            var checkboxes = document.querySelectorAll('.product-checkbox');
            for (var checkbox of checkboxes) {
                checkbox.checked = this.checked;
            }
        }

        // FIX: SweetAlert2 Confirmation Logic
        function confirmDelete(productId) {
            Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Find the hidden form for this product and submit it
                    document.getElementById('delete-form-' + productId).submit();
                }
            })
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/admin/products/index.blade.php ENDPATH**/ ?>