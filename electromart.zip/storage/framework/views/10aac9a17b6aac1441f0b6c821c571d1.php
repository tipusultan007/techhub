<?php $__env->startSection('title', $currentCategory ? $currentCategory->name : 'Shop All Products'); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        /* --- BREADCRUMBS --- */
        .breadcrumbs { margin: 20px 0; font-size: 12px; color: var(--text-muted); }
        .breadcrumbs span { margin: 0 5px; }
        .breadcrumbs a:hover { color: var(--brand-deep-blue); }

        /* Layout */
        .shop-layout { display: grid; grid-template-columns: 260px 1fr; gap: 30px; margin-bottom: 60px; }
        .sidebar { align-self: start; position: sticky; top: 100px; z-index: 40; }

        /* Filters Container */
        .filter-box {
            background: white; border: 1px solid var(--border); border-radius: var(--radius);
            padding: 20px; margin-bottom: 20px; box-shadow: var(--shadow);
        }

        .filter-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }

        /* Collapsible Sections */
        details { margin-bottom: 15px; border-bottom: 1px solid #f1f5f9; padding-bottom: 15px; }
        details:last-of-type { border-bottom: none; }
        summary { cursor: pointer; font-weight: 700; font-size: 13px; display: flex; justify-content: space-between; color: var(--brand-deep-blue); outline: none; }
        summary::-webkit-details-marker { display: none; }
        summary::after { content: '+'; font-size: 16px; font-weight: 400; color: var(--text-muted); }
        details[open] summary::after { content: '-'; }

        .filter-options { margin-top: 10px; max-height: 250px; overflow-y: auto; }

        /* Checkboxes */
        .checkbox-group { display: flex; align-items: center; gap: 10px; font-size: 13px; color: var(--text-muted); cursor: pointer; margin-bottom: 6px; }
        .checkbox-group:hover { color: var(--brand-magenta); }
        .checkbox-group input { accent-color: var(--brand-magenta); width: 16px; height: 16px; border-radius: 4px; border: 1px solid #cbd5e1; }

        /* Price Inputs */
        .price-inputs { display: flex; gap: 5px; margin-bottom: 10px; }
        .price-inputs input { width: 100%; padding: 8px; border: 1px solid var(--border); border-radius: 4px; font-size: 12px; }

        /* Buttons */
        .btn-filter-apply {
            width: 100%; background: var(--brand-deep-blue); color: white; padding: 12px;
            border: none; border-radius: var(--radius); font-weight: 700; cursor: pointer; transition: 0.2s; margin-top: 10px;
        }
        .btn-filter-apply:hover { background: var(--brand-magenta); }

        /* Toolbar */
        .toolbar { background: white; border: 1px solid var(--border); border-radius: var(--radius); padding: 10px 20px; display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; box-shadow: var(--shadow); }
        .sort-select { padding: 8px 10px; border: 1px solid var(--border); border-radius: 4px; font-size: 13px; cursor: pointer; }

        /* Mobile Filter Button (Hidden on Desktop) */
        .mobile-filter-btn { display: none; }
        .mobile-close-btn { display: none; }
        .offcanvas-overlay { display: none; }

        @media (max-width: 750px) {
            .p-price{
                font-size: 14px;
            }
        }
        /* --- RESPONSIVE STYLES --- */
        @media (max-width: 900px) {
            .shop-layout { grid-template-columns: 1fr; }

            /* Offcanvas Sidebar */
            .sidebar {
                position: fixed; top: 0; left: 0; bottom: 0;
                width: 300px;
                height: 100%;
                background: white;
                transform: translateX(-100%); transition: transform 0.3s ease-in-out;
                z-index: 1000; overflow-y: auto; padding: 25px 20px; /* Increased top padding */
                box-shadow: 4px 0 15px rgba(0,0,0,0.1);
            }
            .sidebar.open { transform: translateX(0); }

            /* Overlay */
            .offcanvas-overlay {
                position: fixed; top: 0; left: 0; right: 0; bottom: 0;
                background: rgba(0,0,0,0.5); z-index: 999;
                display: none;
            }
            .offcanvas-overlay.open { display: block; }

            /* Fix Overlap: Mobile Close Button */
            .mobile-close-btn {
                display: flex; align-items: center; justify-content: center;
                position: absolute;
                top: 15px;
                right: 15px;
                background: #f1f5f9; /* Gray background */
                border: none;
                width: 32px; height: 32px; border-radius: 50%; /* Circular shape */
                font-size: 20px; color: var(--text-muted);
                cursor: pointer;
                z-index: 1001; /* Ensure on top */
            }
            .mobile-close-btn:hover { background: #e2e8f0; color: #ef4444; }

            /* Fix Overlap: Add padding to the header inside sidebar so text doesn't touch the X */
            .sidebar .filter-header {
                padding-right: 40px; /* Make space for the absolute close button */
            }

            /* Mobile Filter Trigger Button */
            .mobile-filter-btn {
                display: flex; align-items: center; gap: 5px;
                background: white; border: 1px solid var(--border);
                padding: 8px 15px; border-radius: 4px; font-weight: 600; font-size: 13px;
                margin-bottom: 20px; width: 100%; justify-content: center;
                color: var(--brand-deep-blue);
            }

            /* 2-Column Grid for Mobile */
            .grid-5 {
                grid-template-columns: repeat(2, 1fr) !important;
                gap: 12px !important;
            }

            /* Compact Product Card for Mobile */
            .product-card .card-content { padding: 10px; }
            .product-card .card-title { font-size: 13px; margin-bottom: 5px; }
            .product-card .card-price { font-size: 15px; }
            .product-card .btn-plus { width: 30px; height: 30px; font-size: 16px; }
            .product-card .card-img-wrap { height: 140px; padding: 10px; }
            .product-card .card-cat { font-size: 10px; margin-bottom: 4px; }
            .product-card .card-rating { margin-bottom: 5px; }
            .product-card .card-footer { align-items: center; }
            .product-card .vat-text { display: none; } /* Hide VAT text on small screens to save space */
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Wrap everything in Alpine x-data to control sidebar state -->
    <div class="container" x-data="{ showFilters: false }">

        <div class="breadcrumbs">
            <a href="<?php echo e(url('/')); ?>">Home</a> <span>/</span>
            <span style="color:var(--text-main); font-weight:600;">Shop</span>
        </div>

        <!-- Mobile Filter Button Trigger -->
        <button class="mobile-filter-btn" @click="showFilters = true">
            <i class="ri-filter-3-line"></i> Filter & Sort
        </button>

        <!-- Overlay Background -->
        <div class="offcanvas-overlay" :class="{ 'open': showFilters }" @click="showFilters = false"></div>

        <div class="shop-layout">

            <!-- SIDEBAR FILTER FORM -->
            <aside class="sidebar" :class="{ 'open': showFilters }">

                <!-- Close Button (Mobile Only) -->
                <button type="button" class="mobile-close-btn" @click="showFilters = false">&times;</button>

                <form id="filterForm" action="<?php echo e(route('shop.index')); ?>" method="GET">

                    <!-- Hidden Sort Input -->
                    <input type="hidden" name="sort" id="hiddenSort" value="<?php echo e(request('sort', 'popular')); ?>">

                    <div class="filter-box" style="border:none; padding:0; box-shadow:none;">
                        <div class="filter-header">
                            <span style="font-weight:800; font-size:1.1rem;">Filters</span>
                            <a href="<?php echo e(route('shop.index')); ?>" style="font-size:12px; color:#ef4444; text-decoration:underline;">Clear All</a>
                        </div>

                        <!-- 1. CATEGORIES -->
                        <details open>
                            <summary>Categories</summary>
                            <div class="filter-options">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="checkbox-group">
                                        <input type="checkbox"
                                               name="categories[]"
                                               value="<?php echo e($cat->id); ?>"
                                            <?php echo e((in_array($cat->id, request('categories', [])) || ($currentCategory && $currentCategory->id == $cat->id)) ? 'checked' : ''); ?>>
                                        <?php echo e($cat->name); ?>

                                    </label>

                                    <?php if($cat->children->count() > 0): ?>
                                        <div style="margin-left: 20px; border-left: 2px solid #f1f5f9; padding-left: 10px;">
                                            <?php $__currentLoopData = $cat->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <label class="checkbox-group">
                                                    <input type="checkbox"
                                                           name="categories[]"
                                                           value="<?php echo e($child->id); ?>"
                                                        <?php echo e(in_array($child->id, request('categories', [])) ? 'checked' : ''); ?>>
                                                    <?php echo e($child->name); ?>

                                                </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </details>

                        <!-- 2. BRANDS -->
                        <details open>
                            <summary>Brands</summary>
                            <div class="filter-options">
                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <label class="checkbox-group">
                                        <input type="checkbox" name="brands[]" value="<?php echo e($brand->id); ?>"
                                            <?php echo e(in_array($brand->id, request('brands', [])) ? 'checked' : ''); ?>>
                                        <?php echo e($brand->name); ?>

                                    </label>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </details>

                        <!-- 3. ATTRIBUTES -->
                        <?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attribute): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($attribute->values->count() > 0): ?>
                                <details <?php echo e(request()->has('attribute_values') ? 'open' : ''); ?>>
                                    <summary><?php echo e($attribute->name); ?></summary>
                                    <div class="filter-options">
                                        <?php $__currentLoopData = $attribute->values; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="checkbox-group">
                                                <input type="checkbox"
                                                       name="attribute_values[]"
                                                       value="<?php echo e($value->id); ?>"
                                                    <?php echo e(in_array($value->id, request('attribute_values', [])) ? 'checked' : ''); ?>>
                                                <?php echo e($value->value); ?>

                                            </label>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </details>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <!-- 4. PRICE -->
                        <details open>
                            <summary>Price (AED)</summary>
                            <div class="filter-options">
                                <div class="price-inputs">
                                    <input type="number" name="min_price" placeholder="Min" value="<?php echo e(request('min_price')); ?>">
                                    <input type="number" name="max_price" placeholder="Max" value="<?php echo e(request('max_price')); ?>">
                                </div>
                            </div>
                        </details>

                        <!-- APPLY BUTTON -->
                        <button type="submit" class="btn-filter-apply">Apply Filters</button>

                    </div>
                </form>
            </aside>

            <!-- PRODUCT LISTING -->
            <section class="product-listing">

                <div class="toolbar">
                    <span class="result-count">Showing <?php echo e($products->firstItem() ?? 0); ?>–<?php echo e($products->lastItem() ?? 0); ?> of <?php echo e($products->total()); ?> results</span>

                    <div class="sort-wrap">
                        <span style="font-size:13px; color:#64748b; display:none; @media(min-width:900px){display:inline;}">Sort by:</span>
                        <select class="sort-select" onchange="updateSort(this.value)">
                            <option value="popular" <?php echo e(request('sort') == 'popular' ? 'selected' : ''); ?>>Most Popular</option>
                            <option value="price_low" <?php echo e(request('sort') == 'price_low' ? 'selected' : ''); ?>>Price: Low to High</option>
                            <option value="price_high" <?php echo e(request('sort') == 'price_high' ? 'selected' : ''); ?>>Price: High to Low</option>
                            <option value="newest" <?php echo e(request('sort') == 'newest' ? 'selected' : ''); ?>>Newest Arrivals</option>
                        </select>
                    </div>
                </div>

                <?php if($products->count() > 0): ?>
                    <div class="grid-5" style="grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));">
                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                    <div class="mt-8">
                        <?php echo e($products->links()); ?>

                    </div>
                <?php else: ?>
                    <div style="text-align:center; padding: 60px; background:white; border-radius:8px; border:1px solid #e2e8f0;">
                        <i class="ri-search-line" style="font-size:3rem; color:#cbd5e1; margin-bottom:15px; display:block;"></i>
                        <h3 style="font-weight:700; color:#64748b;">No products found</h3>
                        <p style="color:#94a3b8; font-size:0.9rem;">Try adjusting your filters.</p>
                        <a href="<?php echo e(route('shop.index')); ?>" style="margin-top:15px; display:inline-block; color:var(--brand-magenta); font-weight:600; font-size:0.9rem;">Clear Filters</a>
                    </div>
                <?php endif; ?>

            </section>
        </div>
    </div>

    <!-- Ensure Alpine is loaded -->
    <script src="//unpkg.com/alpinejs" defer></script>

    <script>
        function updateSort(value) {
            document.getElementById('hiddenSort').value = value;
            document.getElementById('filterForm').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/frontend/shop.blade.php ENDPATH**/ ?>