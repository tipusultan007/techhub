<?php $__env->startSection('header', 'Register Serial Numbers'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto">

    <!-- Header Info -->
    <div class="bg-white p-6 rounded-lg shadow mb-6 border-l-4 border-blue-600">
        <div class="flex justify-between items-center">
            <div>
                <h2 class="text-xl font-bold text-gray-800">PO Ref: <?php echo e($purchaseOrder->reference_no); ?></h2>
                <p class="text-gray-500">Supplier: <?php echo e($purchaseOrder->supplier->name); ?></p>
            </div>
            <a href="<?php echo e(route('purchases.show', $purchaseOrder->id)); ?>" class="text-blue-600 hover:underline">
                Back to Order
            </a>
        </div>
    </div>

    <?php if($items->isEmpty()): ?>
        <div class="bg-yellow-50 p-6 rounded-lg text-yellow-700 border border-yellow-200">
            No items in this purchase order require serial numbers.
        </div>
    <?php else: ?>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <!-- Left: List of Items to Scan -->
        <div class="col-span-1 bg-white rounded-lg shadow overflow-hidden">
            <div class="p-4 bg-gray-50 border-b font-bold text-gray-700">Items Requiring Serials</div>
            <ul class="divide-y">
                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Calculate how many serials are already entered -->
                    <?php 
                        $entered = \App\Models\ProductSerial::where('purchase_order_id', $purchaseOrder->id)
                                    ->where('product_id', $item->product_id)
                                    ->where('product_variant_id', $item->product_variant_id)
                                    ->count();
                        $remaining = $item->quantity - $entered;
                        $isComplete = $remaining <= 0;
                    ?>

                    <li class="p-4 hover:bg-blue-50 cursor-pointer transition <?php echo e($isComplete ? 'opacity-50' : ''); ?>" 
                        onclick="selectItem(<?php echo e($item->product_id); ?>, <?php echo e($item->product_variant_id ?? 'null'); ?>, '<?php echo e($item->product->name); ?>', <?php echo e($remaining); ?>)">
                        
                        <div class="flex justify-between items-start">
                            <div>
                                <div class="font-bold text-sm text-gray-800"><?php echo e($item->product->name); ?></div>
                                <?php if($item->variant): ?>
                                    <div class="text-xs text-gray-500"><?php echo e($item->variant->variant_name); ?></div>
                                <?php endif; ?>
                                <div class="text-xs text-gray-400 mt-1">Qty Bought: <?php echo e($item->quantity); ?></div>
                            </div>
                            
                            <div class="text-right">
                                <?php if($isComplete): ?>
                                    <span class="bg-green-100 text-green-800 text-xs px-2 py-1 rounded font-bold">Complete</span>
                                <?php else: ?>
                                    <span class="bg-red-100 text-red-800 text-xs px-2 py-1 rounded font-bold"><?php echo e($remaining); ?> Pending</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>

        <!-- Right: Input Form -->
        <div class="col-span-2 bg-white rounded-lg shadow p-6">
            <div id="selection-placeholder" class="text-center py-20 text-gray-400">
                <i class="fas fa-barcode text-6xl mb-4"></i>
                <p>Select an item from the left to start scanning serials.</p>
            </div>

            <div id="input-area" class="hidden">
                <h3 class="text-lg font-bold text-gray-800 mb-2">Adding Serials for: <span id="selected-name" class="text-blue-600"></span></h3>
                <p class="text-sm text-gray-500 mb-6">Please scan <span id="qty-needed" class="font-bold text-black"></span> serial numbers.</p>

                <form action="<?php echo e(route('serials.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="purchase_order_id" value="<?php echo e($purchaseOrder->id); ?>">
                    <input type="hidden" id="input_product_id" name="serials[0][product_id]">
                    <input type="hidden" id="input_variant_id" name="serials[0][variant_id]">

                    <!-- Dynamic Inputs Container -->
                    <div id="inputs-container" class="space-y-3 mb-6">
                        <!-- Inputs generated by JS -->
                    </div>

                    <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded font-bold hover:bg-green-700 shadow w-full">
                        Save Serial Numbers
                    </button>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<?php $__env->startSection('scripts'); ?>
<script>
    function selectItem(productId, variantId, productName, remaining) {
        if(remaining <= 0) {
            alert("All serials for this item have already been registered.");
            return;
        }

        $('#selection-placeholder').addClass('hidden');
        $('#input-area').removeClass('hidden');
        
        $('#selected-name').text(productName);
        $('#qty-needed').text(remaining);
        $('#input_product_id').val(productId);
        // Handle null variant
        if(variantId !== null) $('#input_variant_id').val(variantId);
        else $('#input_variant_id').removeAttr('name'); // Remove if null to avoid DB errors

        // Generate Input Fields based on remaining qty
        let html = '';
        for(let i=0; i < remaining; i++) {
            html += `
            <div class="flex items-center gap-2">
                <span class="text-gray-400 font-mono w-6">${i+1}.</span>
                <input type="hidden" name="serials[${i}][product_id]" value="${productId}">
                ${variantId !== null ? `<input type="hidden" name="serials[${i}][variant_id]" value="${variantId}">` : ''}
                
                <input type="text" name="serials[${i}][code]" 
                       class="w-full border border-gray-300 rounded p-2 serial-input" 
                       placeholder="Scan IMEI / Serial here" required 
                       onchange="validateSerial(this)">
                <span class="validation-msg text-xs w-24"></span>
            </div>`;
        }
        $('#inputs-container').html(html);
        
        // Focus first input
        $('.serial-input').first().focus();
    }

    // Optional: AJAX Validation to prevent duplicate entry instantly
    function validateSerial(input) {
        let code = $(input).val();
        let msgSpan = $(input).next('.validation-msg');
        
        if(code.length > 0) {
            $.get("<?php echo e(route('serials.check')); ?>", {serial: code}, function(data) {
                if(data.exists) {
                    $(input).addClass('border-red-500').removeClass('border-green-500');
                    msgSpan.text('Duplicate!').addClass('text-red-500').removeClass('text-green-500');
                    $(input).val(''); // Clear it
                } else {
                    $(input).removeClass('border-red-500').addClass('border-green-500');
                    msgSpan.text('OK').removeClass('text-red-500').addClass('text-green-500');
                }
            });
        }
    }
</script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/admin/serials/entry.blade.php ENDPATH**/ ?>