<?php $__env->startSection('header', 'Purchase Order Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="max-w-5xl mx-auto">

        <!-- Top Navigation & Actions -->
        <div class="flex justify-between items-center mb-6">
            <a href="<?php echo e(route('purchases.index')); ?>" class="text-gray-600 hover:text-gray-900 flex items-center font-medium">
                <i class="fas fa-arrow-left mr-2"></i> Back to History
            </a>

            <div class="flex gap-2">
                <!-- Check if any items need serials AND status is received -->
                <?php
                    $needsSerials = $purchase->items->contains(fn($item) => $item->product->has_serial_number);
                ?>

                <?php if($needsSerials && $purchase->status === 'received'): ?>
                    <a href="<?php echo e(route('purchases.serials', $purchase->id)); ?>"
                        class="bg-yellow-500 text-white px-4 py-2 rounded shadow hover:bg-yellow-600 font-bold text-sm flex items-center">
                        <i class="fas fa-barcode mr-2"></i> Register Serials
                    </a>
                <?php endif; ?>

                <!-- Print/Download Button (Optional feature placeholder) -->
                <button onclick="window.print()"
                    class="bg-gray-800 text-white px-4 py-2 rounded shadow hover:bg-gray-700 font-bold text-sm flex items-center">
                    <i class="fas fa-print mr-2"></i> Print
                </button>
            </div>
        </div>

        <!-- Main Content Card -->
        <div class="bg-white rounded-lg shadow-lg overflow-hidden border border-gray-200">

            <!-- Header / Status Bar -->
            <div class="bg-gray-50 px-8 py-6 border-b flex justify-between items-start">
                <div>
                    <h1 class="text-2xl font-bold text-gray-800">PURCHASE ORDER</h1>
                    <p class="text-sm text-gray-500 mt-1">Internal Ref: <span
                            class="font-mono font-bold"><?php echo e($purchase->reference_no); ?></span></p>
                    <p class="text-sm text-gray-500">Date: <?php echo e(\Carbon\Carbon::parse($purchase->date)->format('d M, Y')); ?>

                    </p>
                </div>
                <div class="text-right">
                    <span class="block text-xs text-gray-500 uppercase font-bold mb-1">Status</span>
                    <?php if($purchase->status === 'received'): ?>
                        <span
                            class="inline-flex items-center px-3 py-1 rounded-full text-sm font-bold bg-green-100 text-green-800 border border-green-200">
                            <i class="fas fa-check-circle mr-2"></i> RECEIVED
                        </span>
                    <?php else: ?>
                        <span
                            class="inline-flex items-center px-3 py-1 rounded-full text-sm font-bold bg-yellow-100 text-yellow-800 border border-yellow-200">
                            <i class="fas fa-clock mr-2"></i> PENDING
                        </span>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Supplier & Details Grid -->
            <div class="p-8 grid grid-cols-1 md:grid-cols-2 gap-8 border-b">
                <!-- Supplier Info -->
                <div>
                    <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-3">Vendor / Supplier</h3>
                    <div class="text-gray-900 font-bold text-lg"><?php echo e($purchase->supplier->name); ?></div>
                    <div class="text-gray-600"><?php echo e($purchase->supplier->company_name); ?></div>
                    <div class="text-sm text-gray-500 mt-1"><?php echo e($purchase->supplier->address); ?></div>
                    <div class="text-sm text-gray-500 mt-1">
                        <i class="fas fa-phone mr-1 text-gray-400"></i> <?php echo e($purchase->supplier->phone); ?>

                    </div>
                    <?php if($purchase->supplier->trn_number): ?>
                        <div class="text-sm text-blue-600 mt-2 font-mono bg-blue-50 inline-block px-2 py-1 rounded">
                            TRN: <?php echo e($purchase->supplier->trn_number); ?>

                        </div>
                    <?php endif; ?>
                </div>

                <!-- Notes -->
                <div class="bg-gray-50 p-4 rounded border border-gray-100">
                    <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Notes</h3>
                    <p class="text-sm text-gray-600 italic">
                        <?php echo e($purchase->notes ?? 'No additional notes provided.'); ?>

                    </p>
                </div>
            </div>

            <!-- Items Table -->
            <div class="px-8 py-6">
                <h3 class="text-xs font-bold text-gray-400 uppercase tracking-wider mb-4">Items Ordered</h3>
                <div class="overflow-x-auto border rounded-lg">
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead class="bg-gray-100">
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Product</th>
                                <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">SKU</th>
                                <th class="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Unit Cost</th>
                                <th class="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Qty</th>
                                <th class="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Total (Net)</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-200 bg-white">
                            <?php $__currentLoopData = $purchase->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="hover:bg-gray-50">
                                    <td class="px-6 py-4">
                                        <div class="text-sm font-bold text-gray-900"><?php echo e($item->product->name); ?></div>
                                        <?php if($item->variant): ?>
                                            <div class="text-xs text-gray-500"><?php echo e($item->variant->variant_name); ?></div>
                                        <?php endif; ?>
                                    </td>
                                    <td class="px-6 py-4 text-sm font-mono text-gray-500">
                                        <?php echo e($item->variant ? $item->variant->sku : $item->product->sku); ?>

                                    </td>
                                    <td class="px-6 py-4 text-sm text-right text-gray-600">
                                        <?php echo e(number_format($item->unit_cost, 2)); ?>

                                    </td>
                                    <td class="px-6 py-4 text-sm text-right font-bold text-gray-800">
                                        <?php echo e($item->quantity); ?>

                                    </td>
                                    <td class="px-6 py-4 text-sm text-right font-bold text-gray-900">
                                        <?php echo e(number_format($item->subtotal, 2)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <!-- Financial Summary -->
            <div class="px-8 py-6 bg-gray-50 border-t flex justify-end">
                <div class="w-full md:w-1/3 space-y-3">

                    <!-- Subtotal -->
                    <div class="flex justify-between text-sm text-gray-600">
                        <span>Subtotal (Net Amount)</span>
                        <span
                            class="font-medium"><?php echo e(number_format($purchase->total_cost - $purchase->tax_amount, 2)); ?></span>
                    </div>

                    <!-- Input VAT -->
                    <div class="flex justify-between text-sm text-gray-600">
                        <span>Input VAT (5%)</span>
                        <span class="font-medium"><?php echo e(number_format($purchase->tax_amount, 2)); ?></span>
                    </div>

                    <div class="border-t border-gray-300"></div>

                    <!-- Grand Total -->
                    <div class="flex justify-between text-xl font-bold text-gray-900 pt-2">
                        <span>Grand Total</span>
                        <span>AED <?php echo e(number_format($purchase->total_cost, 2)); ?></span>
                    </div>
                </div>
            </div>

            <div class="px-8 py-4 bg-gray-100 border-t text-center text-xs text-gray-500">
                Recorded by <?php echo e(Auth::user()->name); ?> on <?php echo e($purchase->created_at->format('d M Y H:i')); ?>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/admin/purchases/show.blade.php ENDPATH**/ ?>