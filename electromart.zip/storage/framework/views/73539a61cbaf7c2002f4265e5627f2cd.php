<?php $__env->startSection('title', 'Home | Tech Hub Computer Trading'); ?>
<?php $__env->startSection('meta_description', 'Best deals on Gaming PCs, Laptops, and Components in UAE.'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="hero">

            <!-- MAIN BANNER -->
            <?php if($mainBanner): ?>
                <div class="hero-banner">
                    <!-- Background Image -->
                    <img src="<?php echo e($mainBanner->getFirstMediaUrl('banner_image')); ?>" alt="<?php echo e($mainBanner->title); ?>">

                    <div class="banner-content">
                        <?php if($mainBanner->badge_text): ?>
                            <span style="background:var(--brand-magenta); padding:4px 10px; font-size:11px; border-radius:20px; font-weight:700;">
                    <?php echo e($mainBanner->badge_text); ?>

                </span>
                        <?php endif; ?>

                        
                        <h2><?php echo $mainBanner->title; ?></h2>

                        <p style="margin-bottom:25px; font-size:15px; opacity:0.9;">
                            <?php echo e($mainBanner->subtitle); ?>

                        </p>

                        <?php if($mainBanner->button_text): ?>
                            <a href="<?php echo e($mainBanner->link); ?>" class="btn btn-brand">
                                <?php echo e($mainBanner->button_text); ?>

                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php endif; ?>

            <!-- SIDE BANNERS -->
            <div class="hero-side">

                <!-- Side Top -->
                <?php if($sideTop): ?>
                    <a href="<?php echo e($sideTop->link); ?>" class="promo-box">
                        <div class="promo-text">
                            <h4><?php echo e($sideTop->title); ?></h4>
                            <p><?php echo e($sideTop->subtitle); ?></p>
                        </div>
                        <img src="<?php echo e($sideTop->getFirstMediaUrl('banner_image')); ?>" width="70" alt="<?php echo e($sideTop->title); ?>">
                    </a>
                <?php endif; ?>

                <!-- Side Bottom -->
                <?php if($sideBottom): ?>
                    <a href="<?php echo e($sideBottom->link); ?>" class="promo-box">
                        <div class="promo-text">
                            <h4><?php echo e($sideBottom->title); ?></h4>
                            <p><?php echo e($sideBottom->subtitle); ?></p>
                        </div>
                        <img src="<?php echo e($sideBottom->getFirstMediaUrl('banner_image')); ?>" width="70" alt="<?php echo e($sideBottom->title); ?>">
                    </a>
                <?php endif; ?>

            </div>
        </div>

        <!-- NEW: SERVICE FEATURES ROW -->
        <div class="section-wrapper">
            <div class="services-row">
                <div class="service-box">
                    <div class="s-icon"><i class="ri-macbook-line"></i></div>
                    <div class="s-info">
                        <h4>Laptop Finder</h4>
                        <p>Find Your Laptop Easily</p>
                    </div>
                </div>
                <div class="service-box">
                    <div class="s-icon"><i class="ri-chat-voice-line"></i></div>
                    <div class="s-info">
                        <h4>Raise a Complain</h4>
                        <p>Share your experience</p>
                    </div>
                </div>
                <div class="service-box">
                    <div class="s-icon"><i class="ri-home-gear-line"></i></div>
                    <div class="s-info">
                        <h4>Home Service</h4>
                        <p>Get expert help.</p>
                    </div>
                </div>
                <div class="service-box">
                    <div class="s-icon"><i class="ri-settings-3-line"></i></div>
                    <div class="s-info">
                        <h4>Servicing Center</h4>
                        <p>Repair Your Device</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- FEATURED CATEGORIES GRID -->
        <div class="section-wrapper">
            <div class="section-center-header">
                <h3>Featured Category</h3>
                <p>Get Your Desired Product from Featured Category!</p>
            </div>

            <div class="category-grid">
                <?php $__empty_1 = true; $__currentLoopData = $featuredCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <a href="<?php echo e(route('category.show', ['slug' => $category->slug])); ?>" class="cat-item">
                        <!-- Dynamic Icon with Fallback -->
                        <i class="<?php echo e($category->icon_class ?? 'ri-function-line'); ?>"></i>
                        <span><?php echo e($category->name); ?></span>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full text-center text-gray-400 py-4">
                        No featured categories found.
                    </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- FLASH DEALS -->
        <div class="section-wrapper">
            <div class="section-header">
                <div class="sec-title">
                    <i class="ri-flashlight-fill" style="color: #ef4444;"></i> Flash Sale
                    <div class="deal-header">
                        Ends in:
                        <div class="timer-box">
                            <span class="time-block">02</span> : <span class="time-block">45</span> : <span class="time-block">10</span>
                        </div>
                    </div>
                </div>
                <a href="#" class="view-all">See All Offers <i class="ri-arrow-right-s-line"></i></a>
            </div>

            <div class="grid-5">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if (isset($component)) { $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.product-card','data' => ['product' => $product]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('product-card'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['product' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($product)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $attributes = $__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__attributesOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a)): ?>
<?php $component = $__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a; ?>
<?php unset($__componentOriginal3fd2897c1d6a149cdb97b41db9ff827a); ?>
<?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="col-span-full text-center p-10">
                        <p>No products found.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="mid-banner">
            <div class="mb-text">
                <h3>Upgrade Your Office</h3>
                <p>Exclusive corporate deals on Workstations, Servers, and Networking Gear.</p>
            </div>
            <button class="mb-btn">Request Quote</button>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\electromart\resources\views/home.blade.php ENDPATH**/ ?>