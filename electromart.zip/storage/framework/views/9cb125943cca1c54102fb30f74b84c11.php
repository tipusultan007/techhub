<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['product']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['product']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    // 1. Image
    $image = $product->getFirstMediaUrl('product_images', 'thumb') ?: asset('images/placeholder.jpg');

    // 2. Settings
    $currency = settings('currency_symbol', 'AED');
    $isNew = $product->created_at->diffInDays(now()) <= 7;

    // 3. Logic Initialization
    $isVariable = $product->type === 'variable';
    $priceDisplay = '';
    $oldPriceDisplay = null;
    $isOnSale = false;
    $discountPercent = 0;
    $stock = 0;

    if ($isVariable) {
        // --- VARIABLE PRODUCT LOGIC ---
        // Load variants to prevent N+1 issue if not eager loaded
        $variants = $product->variants;
        $stock = $variants->sum('stock_quantity');

        // Get Min and Max of the ACTIVE prices (what customers pay)
        $minPrice = $variants->map->active_price->min();
        $maxPrice = $variants->map->active_price->max();

        // Determine display string
        if ($minPrice == $maxPrice) {
            $priceDisplay = number_format($minPrice);
        } else {
            $priceDisplay = number_format($minPrice) . ' - ' . number_format($maxPrice);
        }

        // Check if the item is effectively on sale (if Min active price < Min regular price)
        $minRegular = $variants->min('selling_price');
        if ($minPrice < $minRegular) {
            $isOnSale = true;
            $discountPercent = round((($minRegular - $minPrice) / $minRegular) * 100);
        }

    } else {
        // --- SIMPLE PRODUCT LOGIC ---
        $stock = $product->stock_quantity;
        $activePrice = $product->active_price;
        $regularPrice = $product->selling_price;

        $priceDisplay = number_format($activePrice);
        $isOnSale = $product->is_on_sale;

        if ($isOnSale) {
            $oldPriceDisplay = number_format($regularPrice);
            if ($regularPrice > 0) {
                $discountPercent = round((($regularPrice - $activePrice) / $regularPrice) * 100);
            }
        }
    }

    $isOutOfStock = $stock <= 0;
?>

<div class="product-card">

    
    <?php if($isOutOfStock): ?>
        <div class="badge-sale" style="background: #64748b;">Sold Out</div>
    <?php elseif($isOnSale): ?>
        <div class="badge-sale">-<?php echo e($discountPercent); ?>%</div>
    <?php elseif($isNew): ?>
        <div class="badge-new">NEW</div>
    <?php endif; ?>

    
    <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="p-img">
        <img src="<?php echo e($image); ?>" alt="<?php echo e($product->name); ?>" loading="lazy">
    </a>

    <div class="p-details">
        
        <div class="p-cat">
            <?php echo e($product->category->name ?? 'General'); ?>

        </div>

        
        <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="p-title">
            <?php echo e($product->name); ?>

        </a>

        
        <div class="p-price">
            
            <?php echo e($priceDisplay); ?> <span style="font-size:0.7em; margin-left:2px;"><?php echo e($currency); ?></span>

            
            <?php if($oldPriceDisplay): ?>
                <span class="p-old"><?php echo e($oldPriceDisplay); ?></span>
            <?php endif; ?>
        </div>

        
        <?php if($isOutOfStock): ?>
            <button class="add-cart-hover" disabled style="background: #e2e8f0; border-color: #e2e8f0; color: #94a3b8; cursor: not-allowed;">
                Out of Stock
            </button>
        <?php elseif($isVariable): ?>
            <a href="<?php echo e(route('product.show', $product->slug)); ?>" class="add-cart-hover" style="text-align: center; display: block; text-decoration: none;">
                Select Options
            </a>
        <?php else: ?>
            <button type="button"
                    class="add-cart-hover"
                    onclick="addToCart(<?php echo e($product->id); ?>, 1, null)">
                Add to Cart
            </button>
        <?php endif; ?>
    </div>
</div>
<?php /**PATH C:\wamp64\www\electromart\resources\views/components/product-card.blade.php ENDPATH**/ ?>