@extends('layouts.admin')

@section('header', 'Admin Dashboard')

@section('content')
<div class="max-w-7xl mx-auto">
    
    <!-- === STATS CARDS === -->
    <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        
        <!-- Card 1: Daily Sales -->
        <div class="bg-white rounded-lg shadow p-6 border-l-4 border-green-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-green-100 text-green-600">
                    <i class="fas fa-cash-register text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm text-gray-500 font-bold">Today's Sales</p>
                    <p class="text-2xl font-bold text-gray-800">AED {{ number_format($dailySales, 2) }}</p>
                </div>
            </div>
        </div>

        <!-- Card 2: Monthly Sales -->
        <div class="bg-white rounded-lg shadow p-6 border-l-4 border-blue-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                    <i class="fas fa-chart-line text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm text-gray-500 font-bold">Monthly Sales</p>
                    <p class="text-2xl font-bold text-gray-800">AED {{ number_format($monthlySales, 2) }}</p>
                </div>
            </div>
        </div>

        <!-- Card 3: Total Orders -->
        <div class="bg-white rounded-lg shadow p-6 border-l-4 border-purple-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                    <i class="fas fa-shopping-bag text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm text-gray-500 font-bold">Total Orders</p>
                    <p class="text-2xl font-bold text-gray-800">{{ number_format($totalOrders) }}</p>
                </div>
            </div>
        </div>

        <!-- Card 4: Customers -->
        <div class="bg-white rounded-lg shadow p-6 border-l-4 border-orange-500">
            <div class="flex items-center">
                <div class="p-3 rounded-full bg-orange-100 text-orange-600">
                    <i class="fas fa-users text-2xl"></i>
                </div>
                <div class="ml-4">
                    <p class="text-sm text-gray-500 font-bold">Customers</p>
                    <p class="text-2xl font-bold text-gray-800">{{ number_format($totalCustomers) }}</p>
                </div>
            </div>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        <!-- === RECENT ORDERS TABLE === -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200 bg-gray-50 flex justify-between items-center">
                <h3 class="font-bold text-gray-700">Recent Transactions</h3>
                <a href="{{ route('orders.index') }}" class="text-sm text-blue-600 hover:underline">View All</a>
            </div>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Invoice</th>
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Customer</th>
                        <th class="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Total</th>
                        <th class="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Action</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @forelse($recentOrders as $order)
                    <tr>
                        <td class="px-6 py-3 text-sm font-bold text-blue-600">{{ $order->invoice_no }}</td>
                        <td class="px-6 py-3 text-sm text-gray-600">{{ $order->customer_name }}</td>
                        <td class="px-6 py-3 text-sm text-right font-bold">AED {{ number_format($order->total, 2) }}</td>
                        <td class="px-6 py-3 text-right">
                            <a href="{{ route('orders.show', $order) }}" class="text-gray-500 hover:text-blue-600">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    @empty
                    <tr>
                        <td colspan="4" class="px-6 py-4 text-center text-sm text-gray-500">No recent orders.</td>
                    </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        <!-- === LOW STOCK ALERTS === -->
        <div class="bg-white rounded-lg shadow overflow-hidden">
            <div class="px-6 py-4 border-b border-gray-200 bg-red-50 flex justify-between items-center">
                <h3 class="font-bold text-red-700"><i class="fas fa-exclamation-triangle mr-2"></i> Low Stock Alerts</h3>
                <a href="{{ route('products.index') }}" class="text-sm text-red-600 hover:underline">Manage Stock</a>
            </div>
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase">Product / Variant</th>
                        <th class="px-6 py-3 text-right text-xs font-bold text-gray-500 uppercase">Remaining</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <!-- Simple Products -->
                    @foreach($lowStockSimple as $product)
                    <tr>
                        <td class="px-6 py-3 text-sm text-gray-700">{{ $product->name }}</td>
                        <td class="px-6 py-3 text-sm text-right font-bold text-red-600">{{ $product->stock_quantity }}</td>
                    </tr>
                    @endforeach

                    <!-- Variable Products -->
                    @foreach($lowStockVariants as $variant)
                    <tr>
                        <td class="px-6 py-3 text-sm text-gray-700">
                            {{ $variant->product->name }} <br>
                            <span class="text-xs text-gray-500">{{ $variant->variant_name }}</span>
                        </td>
                        <td class="px-6 py-3 text-sm text-right font-bold text-red-600">{{ $variant->stock_quantity }}</td>
                    </tr>
                    @endforeach

                    @if($lowStockSimple->isEmpty() && $lowStockVariants->isEmpty())
                    <tr>
                        <td colspan="2" class="px-6 py-8 text-center text-sm text-green-600">
                            <i class="fas fa-check-circle text-2xl mb-2"></i><br>
                            Inventory levels are healthy!
                        </td>
                    </tr>
                    @endif
                </tbody>
            </table>
        </div>

    </div>
</div>
@endsection