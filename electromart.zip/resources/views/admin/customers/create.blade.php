@extends('layouts.admin')

@section('header', 'Add New Customer')

@section('content')
<div class="max-w-2xl mx-auto bg-white rounded-lg shadow p-6">
    <form action="{{ route('customers.store') }}" method="POST">
        @csrf
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div class="md:col-span-2">
                <label class="block text-sm font-bold text-gray-700">Customer Name <span class="text-red-500">*</span></label>
                <input type="text" name="name" class="w-full mt-1 border border-gray-300 rounded p-2" required>
            </div>
            
            <div>
                <label class="block text-sm font-bold text-gray-700">Phone Number</label>
                <input type="text" name="phone" class="w-full mt-1 border border-gray-300 rounded p-2">
            </div>

            <div>
                <label class="block text-sm font-bold text-gray-700">Email Address</label>
                <input type="email" name="email" class="w-full mt-1 border border-gray-300 rounded p-2">
            </div>

            <div class="md:col-span-2">
                <label class="block text-sm font-bold text-gray-700">TRN Number (UAE B2B)</label>
                <input type="text" name="trn_number" class="w-full mt-1 border border-gray-300 rounded p-2 bg-gray-50" placeholder="Tax Registration Number">
            </div>

            <div class="md:col-span-2">
                <label class="block text-sm font-bold text-gray-700">Address</label>
                <textarea name="address" rows="3" class="w-full mt-1 border border-gray-300 rounded p-2"></textarea>
            </div>
        </div>

        <div class="flex justify-end gap-3">
            <a href="{{ route('customers.index') }}" class="px-4 py-2 bg-gray-200 text-gray-700 rounded hover:bg-gray-300">Cancel</a>
            <button type="submit" class="px-6 py-2 bg-blue-600 text-white rounded font-bold hover:bg-blue-700">Save Customer</button>
        </div>
    </form>
</div>
@endsection