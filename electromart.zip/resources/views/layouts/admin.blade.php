<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'ElectroMart') }} Admin</title>

    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- FontAwesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>

    <!-- Custom Styles -->
    @stack('styles')

    <style>
        /* Sidebar Link States */
        .active-link {
            background-color: #2563eb; /* bg-blue-600 */
            color: white;
        }
        .inactive-link {
            color: #94a3b8; /* text-gray-400 */
        }
        .inactive-link:hover {
            background-color: #334155; /* bg-slate-700 */
            color: white;
        }

        /* Smooth transition for mobile sidebar */
        .sidebar-transition {
            transition: transform 0.3s ease-in-out;
        }
    </style>
</head>
<!-- FIX: Use h-screen and overflow-hidden on body to prevent double scrollbars -->

<body class="bg-gray-100 font-sans antialiased h-screen flex flex-col overflow-hidden">

    <!-- === MOBILE HEADER (Visible only on small screens) === -->
    <div class="md:hidden bg-slate-900 text-white p-4 flex justify-between items-center z-50 flex-shrink-0 shadow-md">
        <span class="font-bold text-xl"><i class="fas fa-bolt text-yellow-400"></i> ElectroMart</span>
        <button id="mobile-menu-btn" class="focus:outline-none text-white">
            <i class="fas fa-bars text-2xl"></i>
        </button>
    </div>

    <!-- === MAIN LAYOUT CONTAINER === -->
    <div class="flex flex-1 h-full overflow-hidden relative">

        <!-- === SIDEBAR === -->
        <!-- FIX:
             1. 'fixed inset-y-0' ensures full height on mobile.
             2. 'md:static' puts it in normal flow on desktop.
             3. 'md:h-full' ensures it stretches on desktop.
        -->
        <aside id="sidebar"
               class="bg-slate-800 text-white w-64 space-y-6 py-7 px-2 absolute inset-y-0 left-0 transform -translate-x-full md:relative md:translate-x-0 sidebar-transition z-40 h-full flex flex-col border-r border-slate-700 shadow-xl">

            <!-- Logo -->
            <div class="text-center mb-6 px-4 hidden md:block">
                <a href="{{ route('dashboard') }}" class="text-2xl font-bold flex items-center justify-center gap-2">
                    <i class="fas fa-bolt text-yellow-400"></i>
                    <span>TechHub</span>
                </a>
                <p class="text-xs text-gray-400 mt-1">Admin Panel</p>
            </div>

            <!-- Navigation Links -->
            <nav class="flex-1 overflow-y-auto px-2 space-y-1">

                <!-- Quick Access -->
                <a href="{{ route('dashboard') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('dashboard') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-tachometer-alt w-6"></i> Dashboard
                </a>

                <!-- Frontend Link -->
                <a href="{{ route('home') }}" target="_blank"
                   class="block py-2.5 px-4 rounded transition duration-200 inactive-link hover:text-blue-300">
                    <i class="fas fa-external-link-alt w-6"></i> Visit Shop
                </a>

                <!-- POS Terminal -->
                @role('Cashier|Manager|Admin')
                <div class="my-4 px-2">
                    <a href="{{ route('pos.index') }}"
                       class="block py-3 px-4 rounded bg-green-600 hover:bg-green-700 text-white font-bold shadow-lg transform hover:scale-105 transition text-center">
                        <i class="fas fa-cash-register mr-2"></i> POS Terminal
                    </a>
                </div>
                @endrole

                <!-- ORDER MANAGEMENT -->
                @role('Manager|Admin')
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mt-6 mb-2">Order Management</p>

                @role('Admin')
                <a href="{{ route('orders.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('orders*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-shopping-cart w-6"></i> All Orders
                </a>
                @endrole

                <a href="{{ route('returns.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('returns*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-undo w-6"></i> Returns & Refunds
                </a>
                @endrole

                <!-- CATALOG & INVENTORY -->
                @role('Manager|Admin')
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mt-6 mb-2">Inventory</p>

                <a href="{{ route('products.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('products*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-box w-6"></i> Products
                </a>

                <a href="{{ route('categories.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('categories*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-tags w-6"></i> Categories
                </a>

                <a href="{{ route('brands.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('brands*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-star w-6"></i> Brands
                </a>

                <a href="{{ route('attributes.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('attributes*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-list-ul w-6"></i> Attributes
                </a>
                @endrole

                <!-- PURCHASING -->
                @role('Manager|Admin')
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mt-6 mb-2">Purchasing</p>

                <a href="{{ route('purchases.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('purchases*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-truck-loading w-6"></i> Purchase Orders
                </a>

                <a href="{{ route('suppliers.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('suppliers*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-people-carry w-6"></i> Suppliers
                </a>
                @endrole

                @role('Manager|Admin')
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mt-6 mb-2">Finance</p>

                <a href="{{ route('expenses.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('expenses*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-money-bill-wave w-6"></i> Expenses
                </a>

                <a href="{{ route('expense-categories.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('expense-categories*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-folder-open w-6"></i> Expense Categories
                </a>
                @endrole

                <!-- CRM -->
                @role('Manager|Admin')
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mt-6 mb-2">CRM</p>
                <a href="{{ route('customers.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('customers*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-users w-6"></i> Customers
                </a>
                @endrole

                <!-- REPORTS -->
                @role('Admin')
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mt-6 mb-2">Reports</p>

                <a href="{{ route('reports.sales') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('reports.sales') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-chart-line w-6"></i> Sales Report
                </a>

                <a href="{{ route('reports.inventory') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('reports.inventory') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-boxes w-6"></i> Inventory Report
                </a>

                <a href="{{ route('reports.vat') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('reports.vat') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-file-invoice-dollar w-6"></i> VAT / Tax
                </a>
                @endrole

                <!-- SYSTEM -->
                @role('Admin')
                <p class="px-4 text-xs font-semibold text-gray-400 uppercase tracking-wider mt-6 mb-2">System</p>

                <a href="{{ route('users.index') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('users*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-user-shield w-6"></i> Users & Roles
                </a>

                <a href="{{ route('settings.edit') }}"
                   class="block py-2.5 px-4 rounded transition duration-200 {{ request()->routeIs('settings.*') ? 'active-link' : 'inactive-link' }}">
                    <i class="fas fa-cog w-6"></i> Settings
                </a>
                @endrole

            </nav>

            <!-- User Profile & Logout -->
            <div class="p-4 bg-slate-900 border-t border-slate-700 flex-shrink-0">
                <div class="flex items-center gap-3">
                    <div class="w-10 h-10 rounded-full bg-blue-600 flex items-center justify-center font-bold text-white shadow-md">
                        {{ substr(Auth::user()->name, 0, 1) }}
                    </div>
                    <div class="flex-1 overflow-hidden">
                        <p class="text-sm font-bold truncate text-white">{{ Auth::user()->name }}</p>
                        <p class="text-xs text-gray-400 truncate">{{ Auth::user()->getRoleNames()->first() ?? 'Staff' }}</p>
                    </div>
                    <form method="POST" action="{{ route('logout') }}">
                        @csrf
                        <button type="submit" class="text-gray-400 hover:text-white transition" title="Logout">
                            <i class="fas fa-sign-out-alt"></i>
                        </button>
                    </form>
                </div>
            </div>
        </aside>

        <!-- === OVERLAY (Mobile) === -->
        <div id="mobile-overlay" class="fixed inset-0 bg-black opacity-50 z-30 hidden md:hidden"></div>

        <!-- === MAIN CONTENT (Scrolls Independently) === -->
        <main class="flex-1 flex flex-col h-full overflow-hidden bg-gray-100">
            <!-- Top Header (Desktop) -->
            <header class="bg-white shadow-sm h-16 hidden md:flex items-center justify-between px-6 flex-shrink-0">
                <h2 class="text-xl font-bold text-gray-800">@yield('header')</h2>
                <div class="text-sm text-gray-500">
                    {{ now()->format('l, d F Y') }}
                </div>
            </header>

            <!-- Mobile Page Title -->
            <div class="md:hidden p-4 bg-white shadow-sm flex-shrink-0">
                <h2 class="text-lg font-bold text-gray-800">@yield('header')</h2>
            </div>

            <!-- Scrollable Content Body -->
            <div class="flex-1 overflow-y-auto p-6 scroll-smooth">
                <!-- Flash Messages -->
                @if (session('success'))
                    <div class="bg-green-100 border-l-4 border-green-500 text-green-700 p-4 mb-6 rounded shadow-sm relative"
                        role="alert">
                        <span class="block sm:inline">{{ session('success') }}</span>
                        <button onclick="this.parentElement.remove()" class="absolute top-0 bottom-0 right-0 px-4 py-3">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                @endif

                @if (session('error'))
                    <div class="bg-red-100 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded shadow-sm relative"
                        role="alert">
                        <span class="block sm:inline">{{ session('error') }}</span>
                        <button onclick="this.parentElement.remove()" class="absolute top-0 bottom-0 right-0 px-4 py-3">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                @endif

                @if ($errors->any())
                    <div class="bg-red-50 border-l-4 border-red-500 text-red-700 p-4 mb-6 rounded">
                        <ul class="list-disc pl-5">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                @yield('content')
            </div>
        </main>
    </div>

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <!-- Mobile Sidebar Logic -->
    <script>
        const btn = document.getElementById('mobile-menu-btn');
        const sidebar = document.getElementById('sidebar');
        const overlay = document.getElementById('mobile-overlay');

        function toggleSidebar() {
            sidebar.classList.toggle('-translate-x-full');
            overlay.classList.toggle('hidden');
        }

        btn.addEventListener('click', toggleSidebar);
        overlay.addEventListener('click', toggleSidebar);
    </script>

    @stack('scripts')
    @yield('scripts')
</body>

</html>
